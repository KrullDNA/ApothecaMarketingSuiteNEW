<?php
/**
 * KDNA Smart Coupons Module
 *
 * Full-featured coupon management: auto-apply, URL coupons, store credit / gift certificates,
 * auto-generation on order, coupon display on cart/checkout/My Account, coupon emailing,
 * coupon printing, cashback rewards, BOGO presets, gift-card images, coupon expiry &
 * unused reminders, send-to-friend form, tax handling, and customisable coupon designs.
 */
defined( 'ABSPATH' ) || exit;

class KDNA_Smart_Coupons {

    // ----- Post-meta keys for individual coupons -----
    const META_AUTO_APPLY              = '_kdna_sc_auto_apply';
    const META_IS_VISIBLE_STOREWIDE    = '_kdna_sc_visible_storewide';
    const META_PICK_PRICE_OF_PRODUCT   = '_kdna_sc_pick_price_of_product';
    const META_AUTO_GENERATE           = '_kdna_sc_auto_generate';
    const META_COUPON_PREFIX           = '_kdna_sc_coupon_prefix';
    const META_COUPON_SUFFIX           = '_kdna_sc_coupon_suffix';
    const META_COUPON_VALIDITY         = '_kdna_sc_coupon_validity';
    const META_VALIDITY_UNIT           = '_kdna_sc_validity_unit';
    const META_DISABLE_EMAIL_RESTRICT  = '_kdna_sc_disable_email_restriction';
    const META_MAX_DISCOUNT            = '_kdna_sc_max_discount';
    const META_RESTRICT_NEW_USER       = '_kdna_sc_restrict_new_user';
    const META_COUPON_MESSAGE          = '_kdna_sc_coupon_message';
    const META_EMAIL_MESSAGE           = '_kdna_sc_email_message';
    const META_EXPIRY_TIME             = '_kdna_sc_expiry_time';
    const META_APPLY_DISCOUNT_ON       = '_kdna_sc_apply_discount_on';

    // ----- Actions tab meta keys -----
    const META_ACTION_ADD_PRODUCTS     = '_kdna_sc_action_add_products';
    const META_ACTION_ADD_QUANTITY     = '_kdna_sc_action_add_quantity';
    const META_ACTION_USER_CAN_CHOOSE  = '_kdna_sc_action_user_can_choose';
    const META_ACTION_DISCOUNT_AMOUNT  = '_kdna_sc_action_discount_amount';
    const META_ACTION_DISCOUNT_TYPE    = '_kdna_sc_action_discount_type';
    const META_ACTION_MESSAGE          = '_kdna_sc_action_message';
    const META_ACTION_INCLUDE_IN_EMAIL = '_kdna_sc_action_include_in_email';

    // ----- Usage restriction meta keys -----
    const META_PRODUCT_BRANDS          = '_kdna_sc_product_brands';
    const META_EXCLUDE_BRANDS          = '_kdna_sc_exclude_brands';
    const META_EXCLUDED_EMAILS         = '_kdna_sc_excluded_emails';

    // ----- Post-meta keys for products -----
    const META_PRODUCT_COUPONS         = '_kdna_sc_coupon_titles';
    const META_PRODUCT_GIFT_IMAGE      = '_kdna_sc_enable_gift_image';

    // ----- Order meta -----
    const META_ORDER_GENERATED         = '_kdna_sc_generated_coupon';
    const META_GIFT_EMAIL              = '_kdna_sc_gift_receiver_email';
    const META_GIFT_MESSAGE            = '_kdna_sc_gift_receiver_message';
    const META_GIFT_TIMESTAMP          = '_kdna_sc_gift_sending_timestamp';
    const META_CASHBACK_ELIGIBLE       = '_kdna_sc_cashback_eligible';

    public function __construct() {
        $s = self::get_settings();

        // ---- URL coupons ----
        if ( $s['enable_url_coupons'] === 'yes' ) {
            add_action( 'wp_loaded', [ $this, 'apply_coupon_from_url' ], 20 );
            add_action( 'init', [ $this, 'add_rewrite_rules' ] );
            add_filter( 'query_vars', [ $this, 'add_query_vars' ] );
            add_action( 'template_redirect', [ $this, 'handle_coupon_endpoint' ] );
        }

        // ---- Auto-apply ----
        if ( $s['enable_auto_apply'] === 'yes' ) {
            add_action( 'woocommerce_before_calculate_totals', [ $this, 'auto_apply_coupons' ], 99 );
        }

        // ---- Display coupons ----
        if ( $s['show_on_cart'] === 'yes' ) {
            add_action( 'woocommerce_before_cart', [ $this, 'display_available_coupons_cart' ] );
        }
        if ( $s['show_on_checkout'] === 'yes' ) {
            add_action( 'woocommerce_before_checkout_form', [ $this, 'display_available_coupons_checkout' ], 5 );
        }
        if ( $s['show_on_myaccount'] === 'yes' ) {
            add_action( 'woocommerce_account_dashboard', [ $this, 'display_myaccount_coupons' ] );
        }
        if ( $s['show_associated_on_product'] === 'yes' ) {
            add_action( 'woocommerce_after_add_to_cart_button', [ $this, 'display_product_coupons' ] );
        }

        // ---- Admin coupon fields ----
        add_action( 'woocommerce_coupon_options', [ $this, 'add_coupon_general_fields' ], 10, 2 );
        add_action( 'woocommerce_coupon_options_usage_restriction', [ $this, 'add_coupon_restriction_fields' ], 10, 2 );
        add_filter( 'woocommerce_coupon_data_tabs', [ $this, 'add_coupon_data_tabs' ] );
        add_action( 'woocommerce_coupon_data_panels', [ $this, 'render_coupon_data_panels' ], 10, 2 );
        add_action( 'woocommerce_coupon_options_save', [ $this, 'save_coupon_fields' ], 10, 2 );

        // ---- WooCommerce Coupons area: Bulk Generate, Import, Send Store Credit ----
        add_action( 'admin_menu', [ $this, 'add_coupon_admin_pages' ] );
        add_action( 'admin_init', [ $this, 'handle_bulk_generate' ] );
        add_action( 'admin_init', [ $this, 'handle_import_coupons' ] );
        add_action( 'admin_init', [ $this, 'handle_send_store_credit' ] );

        // ---- Coupon categories taxonomy ----
        add_action( 'init', [ $this, 'register_coupon_category_taxonomy' ] );

        // ---- Brand restriction validation ----
        add_filter( 'woocommerce_coupon_is_valid_for_product', [ $this, 'validate_brand_restriction' ], 10, 4 );

        // ---- Excluded emails validation ----
        add_filter( 'woocommerce_coupon_is_valid', [ $this, 'validate_excluded_emails' ], 10, 3 );

        // ---- Apply Discount On (cheapest/most expensive) ----
        add_filter( 'woocommerce_coupon_get_discount_amount', [ $this, 'apply_discount_on_filter' ], 10, 5 );

        // ---- Expiry time — append HH:MM to date_expires on save ----
        add_action( 'woocommerce_coupon_options_save', [ $this, 'apply_expiry_time_on_save' ], 20, 2 );

        // ---- Max discount cap ----
        add_filter( 'woocommerce_coupon_get_discount_amount', [ $this, 'cap_max_discount' ], 15, 5 );

        // ---- Execute coupon actions (add products to cart) ----
        add_action( 'woocommerce_applied_coupon', [ $this, 'execute_coupon_actions' ] );

        // ---- Re-apply action discounts on cart recalculation ----
        add_action( 'woocommerce_before_calculate_totals', [ $this, 'reapply_action_discounts' ], 98 );

        // ---- Sample CSV download ----
        add_action( 'wp_ajax_kdna_sc_sample_csv', [ __CLASS__, 'ajax_sample_csv' ] );

        // ---- Product fields (attach coupon to product) ----
        add_action( 'woocommerce_product_options_general_product_data', [ $this, 'add_product_coupon_fields' ] );
        add_action( 'woocommerce_process_product_meta', [ $this, 'save_product_coupon_fields' ] );

        // ---- Store credit discount type ----
        add_filter( 'woocommerce_coupon_discount_types', [ $this, 'add_store_credit_type' ] );
        add_filter( 'woocommerce_coupon_get_discount_amount', [ $this, 'store_credit_discount_amount' ], 10, 5 );

        // ---- Store credit balance deduction on order complete ----
        $statuses = (array) $s['valid_order_statuses'];
        foreach ( $statuses as $status ) {
            add_action( 'woocommerce_order_status_' . $status, [ $this, 'process_order_coupons' ] );
        }

        // ---- Auto-generate coupons on order ----
        foreach ( $statuses as $status ) {
            add_action( 'woocommerce_order_status_' . $status, [ $this, 'auto_generate_coupons_for_order' ], 20 );
        }

        // ---- Cashback rewards ----
        if ( $s['cashback_enabled'] === 'yes' ) {
            foreach ( $statuses as $status ) {
                add_action( 'woocommerce_order_status_' . $status, [ $this, 'process_cashback_reward' ], 30 );
            }
        }

        // ---- Store credit tax handling ----
        if ( $s['include_tax'] === 'yes' ) {
            add_filter( 'woocommerce_coupon_get_discount_amount', [ $this, 'apply_before_tax' ], 20, 5 );
        }

        // ---- Discounted price display ----
        if ( $s['show_discounted_price'] === 'yes' ) {
            add_filter( 'woocommerce_cart_item_price', [ $this, 'display_discounted_price' ], 10, 3 );
        }

        // ---- Delete store credit after full use ----
        if ( $s['delete_after_use'] === 'yes' ) {
            add_action( 'woocommerce_order_status_completed', [ $this, 'maybe_delete_used_credit' ], 99 );
        }

        // ---- Coupon emails ----
        if ( $s['send_coupon_email'] === 'yes' ) {
            add_action( 'kdna_sc_coupon_generated', [ $this, 'send_coupon_email' ], 10, 3 );
        }

        // ---- Coupon printing ----
        if ( $s['enable_printing'] === 'yes' ) {
            add_action( 'wp_ajax_kdna_sc_print_coupon', [ $this, 'ajax_print_coupon' ] );
            add_action( 'wp_ajax_nopriv_kdna_sc_print_coupon', [ $this, 'ajax_print_coupon' ] );
        }

        // ---- Send coupon form (gift to others at checkout) ----
        if ( $s['allow_sending_to_others'] === 'yes' ) {
            add_action( 'woocommerce_after_order_notes', [ $this, 'render_send_coupon_form' ] );
            add_action( 'woocommerce_checkout_update_order_meta', [ $this, 'save_send_coupon_form' ] );
        }

        // ---- Store notice banner ----
        if ( ! empty( $s['storewide_coupon_code'] ) ) {
            add_filter( 'woocommerce_demo_store', [ $this, 'store_notice_coupon' ], 10, 2 );
        }

        // ---- My Account endpoint ----
        add_action( 'init', [ $this, 'register_myaccount_endpoint' ] );
        add_filter( 'woocommerce_account_menu_items', [ $this, 'myaccount_menu_item' ] );
        add_action( 'woocommerce_account_coupons_endpoint', [ $this, 'myaccount_coupons_page' ] );

        // ---- Expiry reminder cron ----
        if ( $s['expiry_reminder_enabled'] === 'yes' ) {
            add_action( 'kdna_sc_expiry_reminder_cron', [ $this, 'send_expiry_reminders' ] );
            if ( ! wp_next_scheduled( 'kdna_sc_expiry_reminder_cron' ) ) {
                wp_schedule_event( time(), 'daily', 'kdna_sc_expiry_reminder_cron' );
            }
        }

        // ---- Unused coupon reminder cron ----
        if ( $s['unused_reminder_enabled'] === 'yes' ) {
            add_action( 'kdna_sc_unused_reminder_cron', [ $this, 'send_unused_reminders' ] );
            if ( ! wp_next_scheduled( 'kdna_sc_unused_reminder_cron' ) ) {
                wp_schedule_event( time(), 'daily', 'kdna_sc_unused_reminder_cron' );
            }
        }

        // ---- Frontend assets ----
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_styles' ] );

        // ---- AJAX apply coupon ----
        add_action( 'wp_ajax_kdna_sc_apply_coupon', [ $this, 'ajax_apply_coupon' ] );
        add_action( 'wp_ajax_nopriv_kdna_sc_apply_coupon', [ $this, 'ajax_apply_coupon' ] );

        // ---- Shortcode ----
        add_shortcode( 'kdna_available_coupons', [ $this, 'shortcode_available_coupons' ] );

        // ---- WC Emails registration ----
        add_filter( 'woocommerce_email_classes', [ $this, 'register_email_classes' ] );
    }

    // =========================================================================
    // Settings
    // =========================================================================

    public static function get_settings() {
        return wp_parse_args(
            get_option( 'kdna_smart_coupons_settings', [] ),
            self::get_default_settings()
        );
    }

    public static function get_default_settings() {
        return [
            // ---- General ----
            'max_coupons_shown'           => '5',
            'coupon_code_length'          => '13',
            'valid_order_statuses'        => [ 'processing', 'completed' ],
            'enable_auto_apply'           => 'yes',
            'delete_after_use'            => 'no',
            'send_coupon_email'           => 'yes',
            'enable_printing'             => 'yes',
            'sell_credit_at_less_price'   => 'no',
            'show_discounted_price'       => 'no',

            // ---- Customize Coupons ----
            'coupon_color_scheme'         => '2b2d42-edf2f4-d90429',
            'custom_bg_color'             => '#39cccc',
            'custom_fg_color'             => '#30050b',
            'custom_third_color'          => '#39cccc',
            'coupon_design'               => 'basic',
            'coupon_email_design'         => 'email-coupon',

            // ---- Display Coupons ----
            'storewide_coupon_code'       => '',
            'store_notice_design'         => 'notification',
            'show_associated_on_product'  => 'no',
            'show_on_myaccount'           => 'yes',
            'show_received_on_myaccount'  => 'no',
            'show_invalid_on_myaccount'   => 'no',
            'show_coupon_description'     => 'no',
            'show_on_cart'                => 'yes',
            'show_on_checkout'            => 'yes',
            'always_show_section'         => 'no',
            'default_section_open'        => 'yes',
            'product_page_text'           => 'You will get following coupon(s) when you buy this item:',

            // ---- Tax ----
            'include_tax'                 => 'no',

            // ---- Labels ----
            'credit_label_singular'       => 'Store Credit',
            'credit_label_plural'         => 'Store Credits',
            'credit_product_cta'          => 'Select options',
            'purchasing_credits_label'    => 'Purchase credit worth',
            'coupons_with_product_text'   => 'You will get following coupon(s) when you buy this item',
            'cart_checkout_label'         => 'Available Coupons ({coupons_count})',
            'myaccount_label'             => 'Available Coupons & Store Credits',

            // ---- Send Coupon Form ----
            'allow_sending_to_others'     => 'yes',
            'send_form_title'             => 'Send Coupons to...',
            'send_form_description'       => '',
            'allow_schedule_sending'      => 'no',
            'combine_emails'              => 'no',

            // ---- Emails ----
            'email_auto_generated'        => 'yes',
            'email_combined'              => 'yes',
            'email_acknowledgement'       => 'yes',
            'email_expiry_reminder'       => 'no',
            'email_store_credit_image'    => 'yes',
            'email_unused_reminder'       => 'no',

            // ---- Expiry & Unused Reminders ----
            'expiry_reminder_enabled'     => 'no',
            'expiry_reminder_days_before' => '7',
            'unused_reminder_enabled'     => 'no',
            'unused_reminder_days'        => '30',
            'unused_max_reminders'        => '3',

            // ---- Cashback Rewards ----
            'cashback_enabled'            => 'no',
            'cashback_amount'             => '',
            'cashback_type'               => 'fixed',
            'cashback_min_order'          => '',
            'cashback_template_coupon'    => '',

            // ---- URL Coupons ----
            'enable_url_coupons'          => 'yes',

            // ---- Legacy compat (kept from v1) ----
            'primary_color'               => '#39cccc',
            'text_color'                  => '#ffffff',
        ];
    }

    // =========================================================================
    // URL Coupons
    // =========================================================================

    public function add_rewrite_rules() {
        add_rewrite_rule(
            '^coupon/([^/]+)/?$',
            'index.php?kdna_coupon_code=$matches[1]',
            'top'
        );
    }

    public function add_query_vars( $vars ) {
        $vars[] = 'kdna_coupon_code';
        return $vars;
    }

    public function handle_coupon_endpoint() {
        $code = get_query_var( 'kdna_coupon_code' );
        if ( empty( $code ) ) {
            return;
        }
        if ( WC()->session ) {
            WC()->session->set( 'kdna_sc_url_coupon', sanitize_text_field( $code ) );
        }
        wp_safe_redirect( wc_get_cart_url() );
        exit;
    }

    public function apply_coupon_from_url() {
        if ( ! empty( $_GET['apply_coupon'] ) ) {
            $code = sanitize_text_field( wp_unslash( $_GET['apply_coupon'] ) );
            if ( WC()->cart && ! WC()->cart->has_discount( $code ) ) {
                WC()->cart->apply_coupon( $code );
            }
            return;
        }
        if ( ! WC()->session ) {
            return;
        }
        $code = WC()->session->get( 'kdna_sc_url_coupon' );
        if ( $code && WC()->cart && ! WC()->cart->has_discount( $code ) ) {
            WC()->cart->apply_coupon( $code );
            WC()->session->set( 'kdna_sc_url_coupon', null );
        }
    }

    // =========================================================================
    // Auto-Apply Coupons
    // =========================================================================

    public function auto_apply_coupons( $cart ) {
        if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
            return;
        }
        $auto_coupons = get_posts( [
            'post_type'      => 'shop_coupon',
            'post_status'    => 'publish',
            'posts_per_page' => 20,
            'meta_query'     => [ [ 'key' => self::META_AUTO_APPLY, 'value' => 'yes' ] ],
            'fields'         => 'ids',
        ] );
        foreach ( $auto_coupons as $coupon_id ) {
            $coupon = new WC_Coupon( $coupon_id );
            $code   = $coupon->get_code();
            if ( $cart->has_discount( $code ) ) {
                continue;
            }
            if ( $coupon->is_valid() ) {
                $cart->apply_coupon( $code );
            }
        }
    }

    // =========================================================================
    // Admin — Coupon Edit Screen Fields
    // =========================================================================

    public function add_coupon_general_fields( $coupon_id, $coupon ) {
        // Smart Coupons fields injected into the WooCommerce General tab (green-highlighted in original plugin).
        echo '<div class="options_group" style="background:#f0fff0;border-top:1px solid #e0e0e0;">';

        woocommerce_wp_text_input( [
            'id'                => self::META_EXPIRY_TIME,
            'label'             => __( 'Coupon expiry time', 'kdna-ecommerce' ),
            'placeholder'       => 'HH:MM',
            'description'       => __( 'Expiry time for this coupon. If not set, the coupon expires at the end of the expiry date.', 'kdna-ecommerce' ),
            'desc_tip'          => true,
            'type'              => 'time',
            'value'             => get_post_meta( $coupon_id, self::META_EXPIRY_TIME, true ),
        ] );

        woocommerce_wp_checkbox( [
            'id'          => self::META_AUTO_APPLY,
            'label'       => __( 'Auto apply?', 'kdna-ecommerce' ),
            'description' => __( 'When checked, and applicable, this discount will apply automatically to the cart / order - without customer needing to know / use the coupon. Auto Apply is an excellent way to setup discount rules. Keep in mind that, at most 5 coupons / discounts will be auto applied on a cart / order.', 'kdna-ecommerce' ),
            'value'       => get_post_meta( $coupon_id, self::META_AUTO_APPLY, true ),
            'cbvalue'     => 'yes',
        ] );

        woocommerce_wp_checkbox( [
            'id'          => self::META_RESTRICT_NEW_USER,
            'label'       => __( 'For new customers?', 'kdna-ecommerce' ),
            'description' => __( "When checked, this coupon can be used only in a customer's very first order.", 'kdna-ecommerce' ),
            'value'       => get_post_meta( $coupon_id, self::META_RESTRICT_NEW_USER, true ),
            'cbvalue'     => 'yes',
        ] );

        woocommerce_wp_checkbox( [
            'id'          => self::META_IS_VISIBLE_STOREWIDE,
            'label'       => __( 'Show to everyone?', 'kdna-ecommerce' ),
            'description' => __( 'When checked, this coupon will be included for display on cart / checkout / My Account pages - for all eligible customers.', 'kdna-ecommerce' ),
            'value'       => get_post_meta( $coupon_id, self::META_IS_VISIBLE_STOREWIDE, true ),
            'cbvalue'     => 'yes',
        ] );

        woocommerce_wp_checkbox( [
            'id'          => self::META_PICK_PRICE_OF_PRODUCT,
            'label'       => __( 'Pick price of product?', 'kdna-ecommerce' ),
            'description' => __( 'When checked and used with auto-generate, the generated coupon amount will equal the product price instead of the template coupon amount.', 'kdna-ecommerce' ),
            'value'       => get_post_meta( $coupon_id, self::META_PICK_PRICE_OF_PRODUCT, true ),
            'cbvalue'     => 'yes',
        ] );

        woocommerce_wp_text_input( [
            'id'          => self::META_MAX_DISCOUNT,
            'label'       => __( 'Max discount', 'kdna-ecommerce' ),
            'description' => __( 'Maximum discount amount this coupon can give. Leave blank for no limit.', 'kdna-ecommerce' ),
            'desc_tip'    => true,
            'type'        => 'text',
            'placeholder' => __( 'No limit', 'kdna-ecommerce' ),
            'value'       => get_post_meta( $coupon_id, self::META_MAX_DISCOUNT, true ),
        ] );

        woocommerce_wp_checkbox( [
            'id'          => self::META_AUTO_GENERATE,
            'label'       => __( 'Auto generate?', 'kdna-ecommerce' ),
            'description' => __( 'When checked, and when this coupon is linked to a product, and when someone places an order containing such product: generates a copy of this coupon with all the settings, assigns a new coupon code and issues that newly generated coupon to the customer, to use in future order/s.', 'kdna-ecommerce' ),
            'value'       => get_post_meta( $coupon_id, self::META_AUTO_GENERATE, true ),
            'cbvalue'     => 'yes',
        ] );

        // Optional coupon code format: Prefix + auto_generated coupon_code + Suffix.
        $prefix = get_post_meta( $coupon_id, self::META_COUPON_PREFIX, true );
        $suffix = get_post_meta( $coupon_id, self::META_COUPON_SUFFIX, true );
        ?>
        <p class="form-field" style="background:#f0fff0;">
            <label><?php esc_html_e( 'Optional coupon code format', 'kdna-ecommerce' ); ?></label>
            <span style="display:inline-flex;align-items:center;gap:6px;">
                <input type="text" name="<?php echo esc_attr( self::META_COUPON_PREFIX ); ?>" value="<?php echo esc_attr( $prefix ); ?>" placeholder="<?php esc_attr_e( 'Prefix', 'kdna-ecommerce' ); ?>" style="width:100px;">
                <code style="padding:4px 8px;background:#e8e8e8;border-radius:3px;"><?php esc_html_e( 'auto generated', 'kdna-ecommerce' ); ?> <strong>coupon_code</strong></code>
                <input type="text" name="<?php echo esc_attr( self::META_COUPON_SUFFIX ); ?>" value="<?php echo esc_attr( $suffix ); ?>" placeholder="<?php esc_attr_e( 'Suffix', 'kdna-ecommerce' ); ?>" style="width:100px;">
            </span>
            <span class="description" style="display:block;margin-top:4px;padding-left:0;"><?php esc_html_e( '(prefix or suffix with up to three letters work best)', 'kdna-ecommerce' ); ?></span>
        </p>
        <?php
        // Expire X Days/Weeks/Months after issuance.
        $validity      = get_post_meta( $coupon_id, self::META_COUPON_VALIDITY, true );
        $validity_unit = get_post_meta( $coupon_id, self::META_VALIDITY_UNIT, true ) ?: 'days';
        ?>
        <p class="form-field" style="background:#f0fff0;">
            <label><?php esc_html_e( 'Expire', 'kdna-ecommerce' ); ?></label>
            <span style="display:inline-flex;align-items:center;gap:6px;">
                <input type="number" name="<?php echo esc_attr( self::META_COUPON_VALIDITY ); ?>" value="<?php echo esc_attr( $validity ); ?>" min="0" style="width:70px;">
                <select name="<?php echo esc_attr( self::META_VALIDITY_UNIT ); ?>">
                    <option value="days" <?php selected( $validity_unit, 'days' ); ?>><?php esc_html_e( 'Days', 'kdna-ecommerce' ); ?></option>
                    <option value="weeks" <?php selected( $validity_unit, 'weeks' ); ?>><?php esc_html_e( 'Weeks', 'kdna-ecommerce' ); ?></option>
                    <option value="months" <?php selected( $validity_unit, 'months' ); ?>><?php esc_html_e( 'Months', 'kdna-ecommerce' ); ?></option>
                    <option value="years" <?php selected( $validity_unit, 'years' ); ?>><?php esc_html_e( 'Years', 'kdna-ecommerce' ); ?></option>
                </select>
                <span><?php esc_html_e( 'after issuance - instead of a fixed expiry date, and at "Expiry time" if set. (Only used for auto-generated coupons)', 'kdna-ecommerce' ); ?></span>
            </span>
        </p>
        <?php

        woocommerce_wp_select( [
            'id'          => self::META_APPLY_DISCOUNT_ON,
            'label'       => __( 'Apply discount on', 'kdna-ecommerce' ),
            'value'       => get_post_meta( $coupon_id, self::META_APPLY_DISCOUNT_ON, true ) ?: 'all_qualifying',
            'options'     => [
                'all_qualifying'    => __( 'All qualifying products', 'kdna-ecommerce' ),
                'cheapest_item'     => __( 'Cheapest qualifying product', 'kdna-ecommerce' ),
                'most_expensive'    => __( 'Most expensive qualifying product', 'kdna-ecommerce' ),
            ],
            'description' => __( 'Which product(s) should this coupon apply its discount to.', 'kdna-ecommerce' ),
            'desc_tip'    => true,
            'style'       => 'background:#f0fff0;',
        ] );

        echo '</div>';
    }

    public function add_coupon_restriction_fields( $coupon_id, $coupon ) {
        // Product brands include/exclude fields (Smart Coupons additions).
        $brands         = get_post_meta( $coupon_id, self::META_PRODUCT_BRANDS, true );
        $exclude_brands = get_post_meta( $coupon_id, self::META_EXCLUDE_BRANDS, true );
        $brand_terms    = get_terms( [ 'taxonomy' => 'product_brand', 'hide_empty' => false ] );
        if ( ! is_wp_error( $brand_terms ) && ! empty( $brand_terms ) ) :
            $brands         = is_array( $brands ) ? $brands : [];
            $exclude_brands = is_array( $exclude_brands ) ? $exclude_brands : [];
        ?>
        <div class="options_group" style="background:#f0fff0;border-top:1px solid #e0e0e0;">
            <p class="form-field">
                <label for="kdna_sc_product_brands"><?php esc_html_e( 'Product brands', 'kdna-ecommerce' ); ?></label>
                <select id="kdna_sc_product_brands" name="<?php echo esc_attr( self::META_PRODUCT_BRANDS ); ?>[]" class="wc-enhanced-select" multiple="multiple" style="width:50%;" data-placeholder="<?php esc_attr_e( 'Any brand', 'kdna-ecommerce' ); ?>">
                    <?php foreach ( $brand_terms as $term ) : ?>
                        <option value="<?php echo esc_attr( $term->term_id ); ?>" <?php selected( in_array( (string) $term->term_id, $brands, true ) ); ?>><?php echo esc_html( $term->name ); ?></option>
                    <?php endforeach; ?>
                </select>
                <?php echo wc_help_tip( __( 'Products must belong to one of these brands for the coupon to apply. Leave empty for any brand.', 'kdna-ecommerce' ) ); ?>
            </p>

            <p class="form-field">
                <label for="kdna_sc_exclude_brands"><?php esc_html_e( 'Exclude brands', 'kdna-ecommerce' ); ?></label>
                <select id="kdna_sc_exclude_brands" name="<?php echo esc_attr( self::META_EXCLUDE_BRANDS ); ?>[]" class="wc-enhanced-select" multiple="multiple" style="width:50%;" data-placeholder="<?php esc_attr_e( 'No brands', 'kdna-ecommerce' ); ?>">
                    <?php foreach ( $brand_terms as $term ) : ?>
                        <option value="<?php echo esc_attr( $term->term_id ); ?>" <?php selected( in_array( (string) $term->term_id, $exclude_brands, true ) ); ?>><?php echo esc_html( $term->name ); ?></option>
                    <?php endforeach; ?>
                </select>
                <?php echo wc_help_tip( __( 'Products from these brands will be excluded from the coupon. Leave empty for no brand exclusion.', 'kdna-ecommerce' ) ); ?>
            </p>
        </div>
        <?php
        endif;

        // Smart Coupons: Restrictions dropdown + Add button.
        $excluded_emails = get_post_meta( $coupon_id, self::META_EXCLUDED_EMAILS, true );
        $excluded_emails = is_array( $excluded_emails ) ? $excluded_emails : [];
        ?>
        <div class="options_group" style="background:#f0fff0;border-top:1px solid #e0e0e0;">
            <p class="form-field" style="display:flex;align-items:center;gap:8px;">
                <label style="min-width:140px;"><?php esc_html_e( 'Smart Coupons: Restrictions', 'kdna-ecommerce' ); ?></label>
                <select id="kdna_sc_restriction_type" style="min-width:200px;">
                    <option value="excluded_emails"><?php esc_html_e( 'Excluded emails', 'kdna-ecommerce' ); ?></option>
                </select>
                <button type="button" class="button" id="kdna_sc_add_restriction"><?php esc_html_e( 'Add', 'kdna-ecommerce' ); ?></button>
            </p>

            <div id="kdna_sc_excluded_emails_field" style="<?php echo empty( $excluded_emails ) ? 'display:none;' : ''; ?>padding:0 12px 12px;">
                <p class="form-field">
                    <label for="kdna_sc_excluded_emails"><?php esc_html_e( 'Excluded emails', 'kdna-ecommerce' ); ?></label>
                    <textarea id="kdna_sc_excluded_emails" name="<?php echo esc_attr( self::META_EXCLUDED_EMAILS ); ?>" rows="3" style="width:50%;" placeholder="<?php esc_attr_e( 'one@example.com, two@example.com', 'kdna-ecommerce' ); ?>"><?php echo esc_textarea( implode( ', ', $excluded_emails ) ); ?></textarea>
                    <?php echo wc_help_tip( __( 'Emails listed here will be blocked from using this coupon. Separate multiple emails with commas.', 'kdna-ecommerce' ) ); ?>
                </p>
            </div>
        </div>
        <script>
        jQuery(function($) {
            $('#kdna_sc_add_restriction').on('click', function() {
                var type = $('#kdna_sc_restriction_type').val();
                if (type === 'excluded_emails') {
                    $('#kdna_sc_excluded_emails_field').show();
                }
            });
        });
        </script>
        <?php
    }

    public function add_coupon_data_tabs( $tabs ) {
        $tabs['kdna_actions'] = [
            'label'  => __( 'Actions', 'kdna-ecommerce' ),
            'target' => 'kdna_actions_data',
            'class'  => '',
        ];
        return $tabs;
    }

    public function render_coupon_data_panels( $coupon_id, $coupon ) {
        $action_products   = get_post_meta( $coupon_id, self::META_ACTION_ADD_PRODUCTS, true );
        $action_qty        = get_post_meta( $coupon_id, self::META_ACTION_ADD_QUANTITY, true ) ?: '1';
        $action_choose     = get_post_meta( $coupon_id, self::META_ACTION_USER_CAN_CHOOSE, true );
        $action_disc_amt   = get_post_meta( $coupon_id, self::META_ACTION_DISCOUNT_AMOUNT, true ) ?: '0.00';
        $action_disc_type  = get_post_meta( $coupon_id, self::META_ACTION_DISCOUNT_TYPE, true ) ?: 'percent';
        $action_message    = get_post_meta( $coupon_id, self::META_ACTION_MESSAGE, true );
        $action_in_email   = get_post_meta( $coupon_id, self::META_ACTION_INCLUDE_IN_EMAIL, true );
        ?>
        <div id="kdna_actions_data" class="panel woocommerce_options_panel" style="background:#f0fff0;">

            <div class="options_group">
                <p style="padding:12px;font-weight:600;font-size:13px;margin:0;border-bottom:1px solid #e0e0e0;">
                    <?php esc_html_e( 'After applying the coupon, do these also...', 'kdna-ecommerce' ); ?>
                </p>
            </div>

            <div class="options_group">
                <p class="form-field">
                    <label for="kdna_sc_action_products"><?php esc_html_e( 'Add products to cart', 'kdna-ecommerce' ); ?></label>
                    <select class="wc-product-search" multiple="multiple" style="width:50%;" id="kdna_sc_action_products" name="<?php echo esc_attr( self::META_ACTION_ADD_PRODUCTS ); ?>[]" data-placeholder="<?php esc_attr_e( 'Search for a product&hellip;', 'kdna-ecommerce' ); ?>" data-action="woocommerce_json_search_products_and_variations">
                        <?php
                        if ( ! empty( $action_products ) ) {
                            $product_ids = is_array( $action_products ) ? $action_products : explode( ',', $action_products );
                            foreach ( $product_ids as $product_id ) {
                                $product = wc_get_product( $product_id );
                                if ( $product ) {
                                    echo '<option value="' . esc_attr( $product_id ) . '" selected="selected">' . esc_html( wp_strip_all_tags( $product->get_formatted_name() ) ) . '</option>';
                                }
                            }
                        }
                        ?>
                    </select>
                    <?php echo wc_help_tip( __( 'Products to automatically add to the cart when this coupon is applied.', 'kdna-ecommerce' ) ); ?>
                </p>

                <p class="form-field">
                    <label for="kdna_sc_action_qty"><?php esc_html_e( 'each with quantity', 'kdna-ecommerce' ); ?></label>
                    <input type="number" id="kdna_sc_action_qty" name="<?php echo esc_attr( self::META_ACTION_ADD_QUANTITY ); ?>" value="<?php echo esc_attr( $action_qty ); ?>" min="1" style="width:70px;">
                    <?php echo wc_help_tip( __( 'How many of each product to add to the cart.', 'kdna-ecommerce' ) ); ?>
                </p>

                <p class="form-field">
                    <label for="kdna_sc_action_choose"><?php esc_html_e( 'users can choose only one', 'kdna-ecommerce' ); ?></label>
                    <input type="checkbox" id="kdna_sc_action_choose" name="<?php echo esc_attr( self::META_ACTION_USER_CAN_CHOOSE ); ?>" value="yes" <?php checked( $action_choose, 'yes' ); ?>>
                    <span class="description"><?php esc_html_e( 'Allow users to choose when multiples are added on the above.', 'kdna-ecommerce' ); ?></span>
                </p>

                <p class="form-field">
                    <label for="kdna_sc_action_disc"><?php esc_html_e( 'with discount of', 'kdna-ecommerce' ); ?></label>
                    <input type="number" id="kdna_sc_action_disc" name="<?php echo esc_attr( self::META_ACTION_DISCOUNT_AMOUNT ); ?>" value="<?php echo esc_attr( $action_disc_amt ); ?>" min="0" step="0.01" style="width:90px;">
                    <select name="<?php echo esc_attr( self::META_ACTION_DISCOUNT_TYPE ); ?>" style="width:auto;">
                        <option value="percent" <?php selected( $action_disc_type, 'percent' ); ?>>%</option>
                        <option value="fixed" <?php selected( $action_disc_type, 'fixed' ); ?>><?php echo esc_html( get_woocommerce_currency_symbol() ); ?></option>
                    </select>
                    <?php echo wc_help_tip( __( 'Discount to apply on the products added to cart by this action.', 'kdna-ecommerce' ) ); ?>
                </p>
            </div>

            <div class="options_group">
                <p class="form-field">
                    <label for="kdna_sc_action_message"><?php esc_html_e( 'Display a message to user', 'kdna-ecommerce' ); ?></label>
                    <textarea id="kdna_sc_action_message" name="<?php echo esc_attr( self::META_ACTION_MESSAGE ); ?>" rows="6" style="width:50%;"><?php echo esc_textarea( $action_message ); ?></textarea>
                    <?php echo wc_help_tip( __( 'Message displayed to the customer when this coupon is applied. HTML allowed.', 'kdna-ecommerce' ) ); ?>
                </p>

                <p class="form-field">
                    <label for="kdna_sc_action_in_email"><?php esc_html_e( 'Include in email?', 'kdna-ecommerce' ); ?></label>
                    <input type="checkbox" id="kdna_sc_action_in_email" name="<?php echo esc_attr( self::META_ACTION_INCLUDE_IN_EMAIL ); ?>" value="yes" <?php checked( $action_in_email, 'yes' ); ?>>
                    <span class="description"><?php esc_html_e( 'Check this box to include this message in order confirmation email.', 'kdna-ecommerce' ); ?></span>
                </p>
            </div>

        </div>
        <?php
    }

    public function save_coupon_fields( $coupon_id, $coupon ) {
        // General tab checkboxes.
        $checkboxes = [
            self::META_AUTO_APPLY,
            self::META_IS_VISIBLE_STOREWIDE,
            self::META_PICK_PRICE_OF_PRODUCT,
            self::META_AUTO_GENERATE,
            self::META_DISABLE_EMAIL_RESTRICT,
            self::META_RESTRICT_NEW_USER,
            self::META_EMAIL_MESSAGE,
            self::META_ACTION_USER_CAN_CHOOSE,
            self::META_ACTION_INCLUDE_IN_EMAIL,
        ];
        foreach ( $checkboxes as $key ) {
            update_post_meta( $coupon_id, $key, isset( $_POST[ $key ] ) ? 'yes' : 'no' );
        }

        // Text / select fields.
        $text_fields = [
            self::META_COUPON_PREFIX,
            self::META_COUPON_SUFFIX,
            self::META_COUPON_VALIDITY,
            self::META_VALIDITY_UNIT,
            self::META_MAX_DISCOUNT,
            self::META_EXPIRY_TIME,
            self::META_APPLY_DISCOUNT_ON,
            self::META_ACTION_ADD_QUANTITY,
            self::META_ACTION_DISCOUNT_AMOUNT,
            self::META_ACTION_DISCOUNT_TYPE,
        ];
        foreach ( $text_fields as $key ) {
            if ( isset( $_POST[ $key ] ) ) {
                update_post_meta( $coupon_id, $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
            }
        }

        // Textarea fields.
        if ( isset( $_POST[ self::META_COUPON_MESSAGE ] ) ) {
            update_post_meta( $coupon_id, self::META_COUPON_MESSAGE, wp_kses_post( wp_unslash( $_POST[ self::META_COUPON_MESSAGE ] ) ) );
        }
        if ( isset( $_POST[ self::META_ACTION_MESSAGE ] ) ) {
            update_post_meta( $coupon_id, self::META_ACTION_MESSAGE, wp_kses_post( wp_unslash( $_POST[ self::META_ACTION_MESSAGE ] ) ) );
        }

        // Action products (array of IDs).
        if ( isset( $_POST[ self::META_ACTION_ADD_PRODUCTS ] ) ) {
            $product_ids = array_map( 'absint', (array) $_POST[ self::META_ACTION_ADD_PRODUCTS ] );
            update_post_meta( $coupon_id, self::META_ACTION_ADD_PRODUCTS, array_filter( $product_ids ) );
        } else {
            delete_post_meta( $coupon_id, self::META_ACTION_ADD_PRODUCTS );
        }

        // Brand restriction arrays.
        if ( isset( $_POST[ self::META_PRODUCT_BRANDS ] ) ) {
            update_post_meta( $coupon_id, self::META_PRODUCT_BRANDS, array_map( 'sanitize_text_field', (array) $_POST[ self::META_PRODUCT_BRANDS ] ) );
        } else {
            delete_post_meta( $coupon_id, self::META_PRODUCT_BRANDS );
        }
        if ( isset( $_POST[ self::META_EXCLUDE_BRANDS ] ) ) {
            update_post_meta( $coupon_id, self::META_EXCLUDE_BRANDS, array_map( 'sanitize_text_field', (array) $_POST[ self::META_EXCLUDE_BRANDS ] ) );
        } else {
            delete_post_meta( $coupon_id, self::META_EXCLUDE_BRANDS );
        }

        // Excluded emails (comma-separated textarea).
        if ( isset( $_POST[ self::META_EXCLUDED_EMAILS ] ) ) {
            $raw = sanitize_textarea_field( wp_unslash( $_POST[ self::META_EXCLUDED_EMAILS ] ) );
            $emails = array_filter( array_map( 'trim', explode( ',', $raw ) ) );
            $emails = array_map( 'sanitize_email', $emails );
            $emails = array_filter( $emails );
            if ( ! empty( $emails ) ) {
                update_post_meta( $coupon_id, self::META_EXCLUDED_EMAILS, $emails );
            } else {
                delete_post_meta( $coupon_id, self::META_EXCLUDED_EMAILS );
            }
        }
    }

    // =========================================================================
    // Coupon Categories Taxonomy
    // =========================================================================

    public function register_coupon_category_taxonomy() {
        register_taxonomy( 'coupon_category', 'shop_coupon', [
            'labels' => [
                'name'              => __( 'Coupon categories', 'kdna-ecommerce' ),
                'singular_name'     => __( 'Coupon category', 'kdna-ecommerce' ),
                'search_items'      => __( 'Search coupon categories', 'kdna-ecommerce' ),
                'all_items'         => __( 'All coupon categories', 'kdna-ecommerce' ),
                'edit_item'         => __( 'Edit coupon category', 'kdna-ecommerce' ),
                'update_item'       => __( 'Update coupon category', 'kdna-ecommerce' ),
                'add_new_item'      => __( 'Add new coupon category', 'kdna-ecommerce' ),
                'new_item_name'     => __( 'New coupon category name', 'kdna-ecommerce' ),
                'menu_name'         => __( 'Coupon categories', 'kdna-ecommerce' ),
                'manage_items'      => __( 'Manage coupon categories', 'kdna-ecommerce' ),
            ],
            'hierarchical' => true,
            'show_ui'      => true,
            'show_in_menu' => false,
            'show_in_rest' => true,
            'query_var'    => true,
            'rewrite'      => false,
        ] );
    }

    // =========================================================================
    // Brand Restriction Validation
    // =========================================================================

    public function validate_brand_restriction( $valid, $product, $coupon, $values ) {
        if ( ! $valid ) {
            return $valid;
        }

        $coupon_id      = $coupon->get_id();
        $allowed_brands = get_post_meta( $coupon_id, self::META_PRODUCT_BRANDS, true );
        $exclude_brands = get_post_meta( $coupon_id, self::META_EXCLUDE_BRANDS, true );

        if ( empty( $allowed_brands ) && empty( $exclude_brands ) ) {
            return $valid;
        }

        // Get product brand term IDs.
        $product_id    = $product->get_id();
        $product_brands = wp_get_post_terms( $product_id, 'product_brand', [ 'fields' => 'ids' ] );
        if ( is_wp_error( $product_brands ) ) {
            $product_brands = [];
        }
        $product_brands = array_map( 'strval', $product_brands );

        // Check allowed brands.
        if ( ! empty( $allowed_brands ) && is_array( $allowed_brands ) ) {
            if ( empty( array_intersect( $product_brands, $allowed_brands ) ) ) {
                return false;
            }
        }

        // Check excluded brands.
        if ( ! empty( $exclude_brands ) && is_array( $exclude_brands ) ) {
            if ( ! empty( array_intersect( $product_brands, $exclude_brands ) ) ) {
                return false;
            }
        }

        return $valid;
    }

    /**
     * Validate excluded emails — block coupon if the current user's email is excluded.
     */
    public function validate_excluded_emails( $valid, $coupon, $discounts ) {
        if ( ! $valid ) {
            return $valid;
        }

        $excluded_emails = get_post_meta( $coupon->get_id(), self::META_EXCLUDED_EMAILS, true );
        if ( empty( $excluded_emails ) ) {
            return $valid;
        }

        // Handle both array (from save handler) and string formats.
        if ( is_array( $excluded_emails ) ) {
            $excluded_list = array_filter( array_map( 'strtolower', array_map( 'trim', $excluded_emails ) ) );
        } else {
            $excluded_list = array_filter( array_map( 'strtolower', array_map( 'trim', preg_split( '/[\n,]+/', $excluded_emails ) ) ) );
        }
        if ( empty( $excluded_list ) ) {
            return $valid;
        }

        // Get the current customer email.
        $email = '';
        if ( is_user_logged_in() ) {
            $current_user = wp_get_current_user();
            $email        = strtolower( $current_user->user_email );
        } elseif ( WC()->customer ) {
            $email = strtolower( WC()->customer->get_billing_email() );
        }

        if ( ! empty( $email ) && in_array( $email, $excluded_list, true ) ) {
            throw new \Exception( __( 'This coupon is not valid for your email address.', 'kdna-ecommerce' ) );
        }

        return $valid;
    }

    // =========================================================================
    // Expiry Time — Append HH:MM to WooCommerce's date_expires on coupon save
    // =========================================================================

    /**
     * After the standard save, adjust the coupon's date_expires to include the HH:MM.
     * Runs at priority 20 so it fires after our main save_coupon_fields (priority 10).
     */
    public function apply_expiry_time_on_save( $coupon_id, $coupon ) {
        $time = get_post_meta( $coupon_id, self::META_EXPIRY_TIME, true );
        if ( empty( $time ) || ! preg_match( '/^\d{1,2}:\d{2}$/', $time ) ) {
            return;
        }

        // WooCommerce stores expiry as a timestamp in the 'date_expires' meta key.
        $coupon_obj = new WC_Coupon( $coupon_id );
        $date_expires = $coupon_obj->get_date_expires();
        if ( ! $date_expires ) {
            return;
        }

        list( $hours, $minutes ) = explode( ':', $time );
        $hours   = absint( $hours );
        $minutes = absint( $minutes );

        // Reset time to midnight then set the desired HH:MM.
        $date_expires->setTime( $hours, $minutes, 0 );
        $coupon_obj->set_date_expires( $date_expires );
        $coupon_obj->save();
    }

    // =========================================================================
    // Apply Discount On — Cheapest / Most Expensive item filter
    // =========================================================================

    /**
     * If the coupon's "Apply Discount On" setting is cheapest_item or most_expensive,
     * only apply the discount to that specific cart item and zero out all others.
     */
    public function apply_discount_on_filter( $discount, $discounting_amount, $cart_item, $single, $coupon ) {
        $apply_on = get_post_meta( $coupon->get_id(), self::META_APPLY_DISCOUNT_ON, true );
        if ( empty( $apply_on ) || $apply_on === 'all_qualifying' ) {
            return $discount;
        }

        // Only applies to percentage and fixed_product discount types.
        $type = $coupon->get_discount_type();
        if ( ! in_array( $type, [ 'percent', 'fixed_product' ], true ) ) {
            return $discount;
        }

        // Find the target cart item (cheapest or most expensive).
        $target_item_key = $this->find_target_cart_item( $coupon, $apply_on );
        if ( ! $target_item_key ) {
            return $discount;
        }

        // Identify the current cart item's key.
        $current_key = $this->get_cart_item_key_for_item( $cart_item );
        if ( $current_key !== $target_item_key ) {
            return 0; // Not the target item — no discount.
        }

        return $discount;
    }

    /**
     * Find the cheapest or most expensive qualifying cart item key.
     */
    private function find_target_cart_item( $coupon, $mode ) {
        if ( ! WC()->cart ) {
            return null;
        }

        $target_key   = null;
        $target_price = null;

        foreach ( WC()->cart->get_cart() as $key => $item ) {
            $product = $item['data'];
            if ( ! $product ) {
                continue;
            }

            // Check if this product is valid for the coupon.
            if ( ! $coupon->is_valid_for_product( $product, $item ) ) {
                continue;
            }

            $price = (float) $product->get_price();
            if ( $mode === 'cheapest_item' ) {
                if ( null === $target_price || $price < $target_price ) {
                    $target_price = $price;
                    $target_key   = $key;
                }
            } elseif ( $mode === 'most_expensive' ) {
                if ( null === $target_price || $price > $target_price ) {
                    $target_price = $price;
                    $target_key   = $key;
                }
            }
        }

        return $target_key;
    }

    /**
     * Get the cart key for a given cart item array.
     */
    private function get_cart_item_key_for_item( $cart_item ) {
        if ( ! WC()->cart ) {
            return null;
        }
        foreach ( WC()->cart->get_cart() as $key => $item ) {
            if ( $item === $cart_item ) {
                return $key;
            }
        }
        // Fallback: match by product ID + variation.
        $pid = isset( $cart_item['product_id'] ) ? $cart_item['product_id'] : 0;
        $vid = isset( $cart_item['variation_id'] ) ? $cart_item['variation_id'] : 0;
        foreach ( WC()->cart->get_cart() as $key => $item ) {
            if ( $item['product_id'] === $pid && $item['variation_id'] === $vid ) {
                return $key;
            }
        }
        return null;
    }

    // =========================================================================
    // Max Discount Cap
    // =========================================================================

    /**
     * Cap the discount amount if a max discount is set for the coupon.
     * Tracks cumulative discount across cart items via a static variable.
     */
    public function cap_max_discount( $discount, $discounting_amount, $cart_item, $single, $coupon ) {
        $max = get_post_meta( $coupon->get_id(), self::META_MAX_DISCOUNT, true );
        if ( empty( $max ) || (float) $max <= 0 ) {
            return $discount;
        }
        $max = (float) $max;

        // Track cumulative discount for this coupon across all cart items.
        static $totals = [];
        $coupon_id = $coupon->get_id();
        if ( ! isset( $totals[ $coupon_id ] ) ) {
            $totals[ $coupon_id ] = 0;
        }

        $remaining = $max - $totals[ $coupon_id ];
        if ( $remaining <= 0 ) {
            return 0;
        }

        $capped = min( $discount, $remaining );
        $totals[ $coupon_id ] += $capped;
        return $capped;
    }

    // =========================================================================
    // WooCommerce Coupons Area — Admin Pages
    // =========================================================================

    public function add_coupon_admin_pages() {
        // Add sub-pages under WooCommerce > Coupons (edit.php?post_type=shop_coupon).
        add_submenu_page(
            'edit.php?post_type=shop_coupon',
            __( 'Bulk Generate', 'kdna-ecommerce' ),
            __( 'Bulk Generate', 'kdna-ecommerce' ),
            'manage_woocommerce',
            'kdna-sc-bulk-generate',
            [ $this, 'render_bulk_generate_page' ]
        );

        add_submenu_page(
            'edit.php?post_type=shop_coupon',
            __( 'Import Coupons', 'kdna-ecommerce' ),
            __( 'Import Coupons', 'kdna-ecommerce' ),
            'manage_woocommerce',
            'kdna-sc-import-coupons',
            [ $this, 'render_import_coupons_page' ]
        );

        add_submenu_page(
            'edit.php?post_type=shop_coupon',
            __( 'Send Store Credit', 'kdna-ecommerce' ),
            __( 'Send Store Credit', 'kdna-ecommerce' ),
            'manage_woocommerce',
            'kdna-sc-send-credit',
            [ $this, 'render_send_credit_page' ]
        );
    }

    private function render_coupon_tabs_nav( $current = 'coupons' ) {
        $tabs = [
            'coupons'         => [ 'label' => __( 'Coupons', 'kdna-ecommerce' ),         'url' => admin_url( 'edit.php?post_type=shop_coupon' ) ],
            'bulk-generate'   => [ 'label' => __( 'Bulk Generate', 'kdna-ecommerce' ),   'url' => admin_url( 'edit.php?post_type=shop_coupon&page=kdna-sc-bulk-generate' ) ],
            'import-coupons'  => [ 'label' => __( 'Import Coupons', 'kdna-ecommerce' ),  'url' => admin_url( 'edit.php?post_type=shop_coupon&page=kdna-sc-import-coupons' ) ],
            'send-credit'     => [ 'label' => __( 'Send Store Credit', 'kdna-ecommerce' ), 'url' => admin_url( 'edit.php?post_type=shop_coupon&page=kdna-sc-send-credit' ) ],
        ];
        echo '<nav class="nav-tab-wrapper woo-nav-tab-wrapper" style="margin-bottom:20px;">';
        foreach ( $tabs as $key => $tab ) {
            $active = ( $key === $current ) ? ' nav-tab-active' : '';
            echo '<a href="' . esc_url( $tab['url'] ) . '" class="nav-tab' . $active . '">' . esc_html( $tab['label'] ) . '</a>';
        }
        echo '</nav>';
    }

    // ---- Bulk Generate Page ----

    public function render_bulk_generate_page() {
        $s = self::get_settings();
        ?>
        <div class="wrap">
            <?php $this->render_coupon_tabs_nav( 'bulk-generate' ); ?>

            <p><?php esc_html_e( 'Need a lot of coupons? You can easily do that with Smart Coupons.', 'kdna-ecommerce' ); ?></p>

            <?php if ( ! empty( $_GET['kdna_sc_generated'] ) ) : ?>
                <div class="notice notice-success"><p><?php printf( esc_html__( '%d coupons generated successfully!', 'kdna-ecommerce' ), absint( $_GET['kdna_sc_generated'] ) ); ?></p></div>
            <?php endif; ?>

            <form method="post" action="">
                <?php wp_nonce_field( 'kdna_sc_bulk_generate', 'kdna_sc_bulk_nonce' ); ?>

                <div class="postbox" style="max-width:800px;">
                    <div class="postbox-header"><h2 style="padding:12px;"><?php esc_html_e( 'Action', 'kdna-ecommerce' ); ?></h2></div>
                    <div class="inside">
                        <table class="form-table">
                            <tr>
                                <th><label for="kdna_sc_bulk_count"><?php esc_html_e( 'Number of coupons to generate', 'kdna-ecommerce' ); ?> <span style="color:red;">*</span></label></th>
                                <td><input type="number" id="kdna_sc_bulk_count" name="kdna_sc_bulk_count" value="10" min="1" max="5000" class="small-text" required></td>
                            </tr>
                            <tr>
                                <th><label><?php esc_html_e( 'Generate coupons and', 'kdna-ecommerce' ); ?></label></th>
                                <td>
                                    <label style="display:block;margin-bottom:8px;"><input type="radio" name="kdna_sc_bulk_action" value="store" checked> <?php esc_html_e( 'Add to store', 'kdna-ecommerce' ); ?></label>
                                    <label style="display:block;margin-bottom:8px;"><input type="radio" name="kdna_sc_bulk_action" value="csv"> <?php esc_html_e( 'Export to CSV', 'kdna-ecommerce' ); ?> <span class="description">(<?php esc_html_e( 'Does not add to store, but creates a .csv file, that you can import later', 'kdna-ecommerce' ); ?>)</span></label>
                                    <label style="display:block;"><input type="radio" name="kdna_sc_bulk_action" value="email"> <?php esc_html_e( 'Email to recipients', 'kdna-ecommerce' ); ?> <span class="description">(<?php esc_html_e( 'Add to store and email generated coupons to recipients', 'kdna-ecommerce' ); ?>)</span></label>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="postbox" style="max-width:800px;">
                    <div class="postbox-header"><h2 style="padding:12px;"><?php esc_html_e( 'Coupon Description', 'kdna-ecommerce' ); ?> <span class="description">(<?php esc_html_e( 'This will add the same coupon description in all the bulk generated coupons', 'kdna-ecommerce' ); ?>)</span></h2></div>
                    <div class="inside">
                        <textarea name="kdna_sc_bulk_description" rows="3" style="width:100%;" placeholder="<?php esc_attr_e( 'Description (optional)', 'kdna-ecommerce' ); ?>"></textarea>
                    </div>
                </div>

                <div class="postbox" style="max-width:800px;">
                    <div class="postbox-header"><h2 style="padding:12px;"><?php esc_html_e( 'Coupon Data', 'kdna-ecommerce' ); ?></h2></div>
                    <div class="inside">
                        <table class="form-table">
                            <tr>
                                <th><label><?php esc_html_e( 'Discount type', 'kdna-ecommerce' ); ?></label></th>
                                <td>
                                    <select name="kdna_sc_bulk_discount_type" style="min-width:200px;">
                                        <option value="percent"><?php esc_html_e( 'Percentage discount', 'kdna-ecommerce' ); ?></option>
                                        <option value="fixed_cart"><?php esc_html_e( 'Fixed cart discount', 'kdna-ecommerce' ); ?></option>
                                        <option value="fixed_product"><?php esc_html_e( 'Fixed product discount', 'kdna-ecommerce' ); ?></option>
                                        <option value="store_credit"><?php echo esc_html( ( $s['credit_label_singular'] ?: 'Store Credit' ) . ' / Gift Certificate' ); ?></option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label><?php esc_html_e( 'Coupon amount', 'kdna-ecommerce' ); ?></label></th>
                                <td><input type="number" name="kdna_sc_bulk_amount" value="0" min="0" step="any" class="small-text"></td>
                            </tr>
                            <tr>
                                <th><label><?php esc_html_e( 'Allow free shipping', 'kdna-ecommerce' ); ?></label></th>
                                <td><label><input type="checkbox" name="kdna_sc_bulk_free_shipping" value="yes"> <?php esc_html_e( 'Tick this box if the coupon grants free shipping.', 'kdna-ecommerce' ); ?></label></td>
                            </tr>
                            <tr>
                                <th><label><?php esc_html_e( 'Coupon expiry date', 'kdna-ecommerce' ); ?></label></th>
                                <td><input type="date" name="kdna_sc_bulk_expiry_date" placeholder="YYYY-MM-DD"></td>
                            </tr>
                            <tr style="background:#f0fff0;">
                                <th><label><?php esc_html_e( 'Coupon expiry time', 'kdna-ecommerce' ); ?></label></th>
                                <td><input type="time" name="kdna_sc_bulk_expiry_time" placeholder="HH:MM"></td>
                            </tr>
                            <tr style="background:#f0fff0;">
                                <th><label><?php esc_html_e( 'For new customers?', 'kdna-ecommerce' ); ?></label></th>
                                <td><label><input type="checkbox" name="kdna_sc_bulk_new_customers" value="yes"> <?php esc_html_e( "When checked, this coupon can be used only in a customer's very first order.", 'kdna-ecommerce' ); ?></label></td>
                            </tr>
                            <tr style="background:#f0fff0;">
                                <th><label><?php esc_html_e( 'Optional coupon code format', 'kdna-ecommerce' ); ?></label></th>
                                <td>
                                    <span style="display:inline-flex;align-items:center;gap:6px;">
                                        <input type="text" name="kdna_sc_bulk_prefix" placeholder="<?php esc_attr_e( 'Prefix', 'kdna-ecommerce' ); ?>" style="width:100px;">
                                        <code style="padding:4px 8px;background:#e8e8e8;border-radius:3px;"><?php esc_html_e( 'auto generated', 'kdna-ecommerce' ); ?> <strong>coupon_code</strong></code>
                                        <input type="text" name="kdna_sc_bulk_suffix" placeholder="<?php esc_attr_e( 'Suffix', 'kdna-ecommerce' ); ?>" style="width:100px;">
                                    </span>
                                    <p class="description"><?php esc_html_e( '(prefix or suffix with up to three letters work best)', 'kdna-ecommerce' ); ?></p>
                                </td>
                            </tr>
                            <tr style="background:#f0fff0;">
                                <th><label><?php esc_html_e( 'Expire', 'kdna-ecommerce' ); ?></label></th>
                                <td>
                                    <span style="display:inline-flex;align-items:center;gap:6px;">
                                        <input type="number" name="kdna_sc_bulk_validity" value="0" min="0" style="width:70px;">
                                        <select name="kdna_sc_bulk_validity_unit">
                                            <option value="days"><?php esc_html_e( 'Days', 'kdna-ecommerce' ); ?></option>
                                            <option value="weeks"><?php esc_html_e( 'Weeks', 'kdna-ecommerce' ); ?></option>
                                            <option value="months"><?php esc_html_e( 'Months', 'kdna-ecommerce' ); ?></option>
                                        </select>
                                        <span><?php esc_html_e( 'after issuance', 'kdna-ecommerce' ); ?></span>
                                    </span>
                                </td>
                            </tr>
                            <tr style="background:#f0fff0;">
                                <th><label><?php esc_html_e( 'Apply discount on', 'kdna-ecommerce' ); ?></label></th>
                                <td>
                                    <select name="kdna_sc_bulk_apply_on">
                                        <option value="all_qualifying"><?php esc_html_e( 'All qualifying products', 'kdna-ecommerce' ); ?></option>
                                        <option value="cheapest_item"><?php esc_html_e( 'Cheapest qualifying product', 'kdna-ecommerce' ); ?></option>
                                        <option value="most_expensive"><?php esc_html_e( 'Most expensive qualifying product', 'kdna-ecommerce' ); ?></option>
                                    </select>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

                <?php submit_button( __( 'Apply', 'kdna-ecommerce' ), 'primary', 'kdna_sc_do_bulk_generate' ); ?>
            </form>
        </div>
        <?php
    }

    public function handle_bulk_generate() {
        if ( ! isset( $_POST['kdna_sc_do_bulk_generate'] ) || ! wp_verify_nonce( $_POST['kdna_sc_bulk_nonce'] ?? '', 'kdna_sc_bulk_generate' ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        $count         = absint( $_POST['kdna_sc_bulk_count'] ?? 10 );
        $action_type   = sanitize_text_field( $_POST['kdna_sc_bulk_action'] ?? 'store' );
        $discount_type = sanitize_text_field( $_POST['kdna_sc_bulk_discount_type'] ?? 'percent' );
        $amount        = (float) ( $_POST['kdna_sc_bulk_amount'] ?? 0 );
        $free_shipping = isset( $_POST['kdna_sc_bulk_free_shipping'] ) ? 'yes' : 'no';
        $expiry_date   = sanitize_text_field( $_POST['kdna_sc_bulk_expiry_date'] ?? '' );
        $expiry_time   = sanitize_text_field( $_POST['kdna_sc_bulk_expiry_time'] ?? '' );
        $new_cust      = isset( $_POST['kdna_sc_bulk_new_customers'] );
        $prefix        = sanitize_text_field( $_POST['kdna_sc_bulk_prefix'] ?? '' );
        $suffix        = sanitize_text_field( $_POST['kdna_sc_bulk_suffix'] ?? '' );
        $validity      = absint( $_POST['kdna_sc_bulk_validity'] ?? 0 );
        $validity_unit = sanitize_text_field( $_POST['kdna_sc_bulk_validity_unit'] ?? 'days' );
        $apply_on      = sanitize_text_field( $_POST['kdna_sc_bulk_apply_on'] ?? 'all_qualifying' );
        $description   = sanitize_textarea_field( $_POST['kdna_sc_bulk_description'] ?? '' );

        $s = self::get_settings();
        $csv_rows = [];
        $generated = 0;

        for ( $i = 0; $i < $count; $i++ ) {
            $code = $this->generate_coupon_code( 0, $s );
            $code = strtolower( $prefix . $code . $suffix );

            if ( $action_type === 'csv' ) {
                $csv_rows[] = [
                    'code'          => $code,
                    'discount_type' => $discount_type,
                    'amount'        => $amount,
                    'free_shipping' => $free_shipping,
                    'expiry_date'   => $expiry_date,
                    'description'   => $description,
                ];
                $generated++;
                continue;
            }

            $coupon = new WC_Coupon();
            $coupon->set_code( $code );
            $coupon->set_discount_type( $discount_type );
            $coupon->set_amount( $amount );
            $coupon->set_free_shipping( $free_shipping === 'yes' );
            $coupon->set_description( $description );

            if ( $expiry_date ) {
                $expiry_str = $expiry_date;
                if ( $expiry_time ) {
                    $expiry_str .= ' ' . $expiry_time;
                }
                $coupon->set_date_expires( strtotime( $expiry_str ) );
            } elseif ( $validity > 0 ) {
                $expiry = new WC_DateTime();
                $expiry->modify( "+{$validity} {$validity_unit}" );
                $coupon->set_date_expires( $expiry );
            }

            $coupon->save();

            if ( $new_cust ) {
                update_post_meta( $coupon->get_id(), self::META_RESTRICT_NEW_USER, 'yes' );
            }
            if ( $apply_on !== 'all_qualifying' ) {
                update_post_meta( $coupon->get_id(), self::META_APPLY_DISCOUNT_ON, $apply_on );
            }
            if ( $expiry_time ) {
                update_post_meta( $coupon->get_id(), self::META_EXPIRY_TIME, $expiry_time );
            }

            $generated++;
        }

        if ( $action_type === 'csv' && ! empty( $csv_rows ) ) {
            header( 'Content-Type: text/csv; charset=utf-8' );
            header( 'Content-Disposition: attachment; filename=coupons-' . gmdate( 'Y-m-d' ) . '.csv' );
            $output = fopen( 'php://output', 'w' );
            fputcsv( $output, [ 'code', 'discount_type', 'amount', 'free_shipping', 'expiry_date', 'description' ] );
            foreach ( $csv_rows as $row ) {
                fputcsv( $output, $row );
            }
            fclose( $output );
            exit;
        }

        wp_safe_redirect( add_query_arg( [
            'post_type'        => 'shop_coupon',
            'page'             => 'kdna-sc-bulk-generate',
            'kdna_sc_generated' => $generated,
        ], admin_url( 'edit.php' ) ) );
        exit;
    }

    // ---- Import Coupons Page ----

    public function render_import_coupons_page() {
        ?>
        <div class="wrap">
            <?php $this->render_coupon_tabs_nav( 'import-coupons' ); ?>

            <p><?php esc_html_e( 'Hi there! Upload a CSV file with coupons details to import them into your shop.', 'kdna-ecommerce' ); ?></p>
            <p><?php esc_html_e( 'The CSV must adhere to a specific format and include a header row.', 'kdna-ecommerce' ); ?>
                <a href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=kdna_sc_sample_csv' ) ); ?>"><?php esc_html_e( 'Click here to download a sample', 'kdna-ecommerce' ); ?></a>
            </p>
            <p><strong><?php esc_html_e( 'Note:', 'kdna-ecommerce' ); ?></strong> <?php esc_html_e( 'If any coupon from the CSV file already exists in the store, it will not update the existing coupon, instead a new coupon will be imported & the previous coupon with the same code will become inactive.', 'kdna-ecommerce' ); ?></p>
            <p><?php esc_html_e( 'Ready to import? Choose a .csv file, then click "Upload file".', 'kdna-ecommerce' ); ?></p>

            <?php if ( ! empty( $_GET['kdna_sc_imported'] ) ) : ?>
                <div class="notice notice-success"><p><?php printf( esc_html__( '%d coupons imported successfully!', 'kdna-ecommerce' ), absint( $_GET['kdna_sc_imported'] ) ); ?></p></div>
            <?php endif; ?>

            <form method="post" enctype="multipart/form-data" action="">
                <?php wp_nonce_field( 'kdna_sc_import_coupons', 'kdna_sc_import_nonce' ); ?>

                <div class="postbox" style="max-width:800px;">
                    <div class="inside" style="text-align:center;padding:50px 20px;">
                        <p>
                            <label for="kdna_sc_csv_file" class="button button-hero" style="cursor:pointer;">
                                <?php esc_html_e( 'Choose a CSV file', 'kdna-ecommerce' ); ?> &#x1f4c1;
                            </label>
                            <input type="file" id="kdna_sc_csv_file" name="kdna_sc_csv_file" accept=".csv" style="display:none;" onchange="document.getElementById('kdna_sc_csv_name').textContent=this.files[0]?.name||'';">
                        </p>
                        <p id="kdna_sc_csv_name" style="font-weight:600;"></p>
                        <p class="description"><?php printf( esc_html__( 'Maximum file size: %s', 'kdna-ecommerce' ), esc_html( size_format( wp_max_upload_size() ) ) ); ?></p>
                    </div>
                </div>

                <?php submit_button( __( 'Upload file', 'kdna-ecommerce' ), 'primary', 'kdna_sc_do_import' ); ?>
            </form>
        </div>
        <?php
    }

    public function handle_import_coupons() {
        if ( ! isset( $_POST['kdna_sc_do_import'] ) || ! wp_verify_nonce( $_POST['kdna_sc_import_nonce'] ?? '', 'kdna_sc_import_coupons' ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) || empty( $_FILES['kdna_sc_csv_file']['tmp_name'] ) ) {
            return;
        }

        $file = fopen( $_FILES['kdna_sc_csv_file']['tmp_name'], 'r' );
        if ( ! $file ) {
            return;
        }

        $header = fgetcsv( $file );
        if ( ! $header ) {
            fclose( $file );
            return;
        }
        $header = array_map( 'strtolower', array_map( 'trim', $header ) );
        $imported = 0;

        while ( ( $row = fgetcsv( $file ) ) !== false ) {
            $data = array_combine( $header, $row );
            if ( empty( $data['code'] ) ) {
                continue;
            }

            $coupon = new WC_Coupon();
            $coupon->set_code( sanitize_text_field( $data['code'] ) );
            $coupon->set_discount_type( sanitize_text_field( $data['discount_type'] ?? 'fixed_cart' ) );
            $coupon->set_amount( (float) ( $data['amount'] ?? 0 ) );
            $coupon->set_description( sanitize_text_field( $data['description'] ?? '' ) );

            if ( ! empty( $data['free_shipping'] ) && $data['free_shipping'] === 'yes' ) {
                $coupon->set_free_shipping( true );
            }
            if ( ! empty( $data['expiry_date'] ) ) {
                $coupon->set_date_expires( strtotime( $data['expiry_date'] ) );
            }
            if ( ! empty( $data['individual_use'] ) && $data['individual_use'] === 'yes' ) {
                $coupon->set_individual_use( true );
            }
            if ( ! empty( $data['usage_limit'] ) ) {
                $coupon->set_usage_limit( absint( $data['usage_limit'] ) );
            }
            if ( ! empty( $data['usage_limit_per_user'] ) ) {
                $coupon->set_usage_limit_per_user( absint( $data['usage_limit_per_user'] ) );
            }
            if ( ! empty( $data['minimum_amount'] ) ) {
                $coupon->set_minimum_amount( (float) $data['minimum_amount'] );
            }
            if ( ! empty( $data['maximum_amount'] ) ) {
                $coupon->set_maximum_amount( (float) $data['maximum_amount'] );
            }
            if ( ! empty( $data['email_restrictions'] ) ) {
                $coupon->set_email_restrictions( array_map( 'trim', explode( '|', $data['email_restrictions'] ) ) );
            }
            if ( ! empty( $data['product_ids'] ) ) {
                $coupon->set_product_ids( array_map( 'absint', explode( '|', $data['product_ids'] ) ) );
            }
            if ( ! empty( $data['product_categories'] ) ) {
                $coupon->set_product_categories( array_map( 'absint', explode( '|', $data['product_categories'] ) ) );
            }

            // Deactivate existing coupon with same code.
            $existing = wc_get_coupon_id_by_code( sanitize_text_field( $data['code'] ) );
            if ( $existing ) {
                wp_update_post( [ 'ID' => $existing, 'post_status' => 'draft' ] );
            }

            $coupon->save();
            $imported++;
        }

        fclose( $file );

        wp_safe_redirect( add_query_arg( [
            'post_type'        => 'shop_coupon',
            'page'             => 'kdna-sc-import-coupons',
            'kdna_sc_imported' => $imported,
        ], admin_url( 'edit.php' ) ) );
        exit;
    }

    // ---- Send Store Credit Page ----

    public function render_send_credit_page() {
        ?>
        <div class="wrap">
            <?php $this->render_coupon_tabs_nav( 'send-credit' ); ?>

            <p><?php esc_html_e( 'Quickly create and email Store Credit or Gift Card to one or more people.', 'kdna-ecommerce' ); ?></p>

            <?php if ( ! empty( $_GET['kdna_sc_credit_sent'] ) ) : ?>
                <div class="notice notice-success"><p><?php esc_html_e( 'Store credit sent successfully!', 'kdna-ecommerce' ); ?></p></div>
            <?php endif; ?>

            <form method="post" action="">
                <?php wp_nonce_field( 'kdna_sc_send_credit', 'kdna_sc_credit_nonce' ); ?>

                <div class="postbox" style="max-width:800px;">
                    <div class="inside">
                        <table class="form-table">
                            <tr>
                                <th><label for="kdna_sc_credit_to"><?php esc_html_e( 'Send to', 'kdna-ecommerce' ); ?><span style="color:red;">*</span></label></th>
                                <td>
                                    <input type="text" id="kdna_sc_credit_to" name="kdna_sc_credit_to" class="regular-text" placeholder="johnsmith@example.com" required style="min-width:400px;">
                                    <span class="description"><?php esc_html_e( 'Use comma "," to separate multiple email addresses', 'kdna-ecommerce' ); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="kdna_sc_credit_amount"><?php esc_html_e( 'Worth', 'kdna-ecommerce' ); ?><span style="color:red;">*</span></label></th>
                                <td>
                                    <span style="display:inline-flex;align-items:center;gap:4px;">
                                        <?php echo esc_html( get_woocommerce_currency_symbol() ); ?>
                                        <input type="number" id="kdna_sc_credit_amount" name="kdna_sc_credit_amount" value="0.00" min="0.01" step="0.01" class="small-text" required>
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="kdna_sc_credit_expiry"><?php esc_html_e( 'Expiry Date', 'kdna-ecommerce' ); ?></label></th>
                                <td><input type="date" id="kdna_sc_credit_expiry" name="kdna_sc_credit_expiry" placeholder="YYYY-MM-DD"></td>
                            </tr>
                            <tr>
                                <th><label for="kdna_sc_credit_message"><?php esc_html_e( 'Message', 'kdna-ecommerce' ); ?> <span class="description">(<?php esc_html_e( 'optional', 'kdna-ecommerce' ); ?>)</span></label></th>
                                <td>
                                    <?php
                                    wp_editor( '', 'kdna_sc_credit_message', [
                                        'textarea_name' => 'kdna_sc_credit_message',
                                        'textarea_rows' => 8,
                                        'media_buttons' => true,
                                        'teeny'         => false,
                                        'quicktags'     => true,
                                    ] );
                                    ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

                <p>
                    <?php submit_button( __( 'Send', 'kdna-ecommerce' ), 'primary', 'kdna_sc_do_send_credit', false ); ?>
                    <button type="button" class="button" id="kdna_sc_preview_email" style="margin-left:8px;"><?php esc_html_e( 'Preview Email', 'kdna-ecommerce' ); ?></button>
                </p>
            </form>
        </div>
        <?php
    }

    public function handle_send_store_credit() {
        if ( ! isset( $_POST['kdna_sc_do_send_credit'] ) || ! wp_verify_nonce( $_POST['kdna_sc_credit_nonce'] ?? '', 'kdna_sc_send_credit' ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        $emails  = array_map( 'sanitize_email', array_map( 'trim', explode( ',', $_POST['kdna_sc_credit_to'] ?? '' ) ) );
        $amount  = (float) ( $_POST['kdna_sc_credit_amount'] ?? 0 );
        $expiry  = sanitize_text_field( $_POST['kdna_sc_credit_expiry'] ?? '' );
        $message = wp_kses_post( wp_unslash( $_POST['kdna_sc_credit_message'] ?? '' ) );
        $s       = self::get_settings();

        if ( $amount <= 0 || empty( $emails ) ) {
            return;
        }

        foreach ( $emails as $email ) {
            if ( ! is_email( $email ) ) {
                continue;
            }

            $code = $this->generate_coupon_code( 0, $s );
            $coupon = new WC_Coupon();
            $coupon->set_code( $code );
            $coupon->set_discount_type( 'store_credit' );
            $coupon->set_amount( $amount );
            $coupon->set_email_restrictions( [ $email ] );
            $coupon->set_usage_limit( 0 );

            if ( $expiry ) {
                $coupon->set_date_expires( strtotime( $expiry ) );
            }

            $coupon->save();

            if ( $message ) {
                update_post_meta( $coupon->get_id(), self::META_COUPON_MESSAGE, $message );
            }

            // Send email.
            $subject = sprintf( __( 'You have received a %s!', 'kdna-ecommerce' ), $s['credit_label_singular'] ?: 'Store Credit' );
            $body    = $this->build_coupon_email_html( $coupon, null );
            if ( $message ) {
                $body .= '<div style="margin-top:15px;">' . $message . '</div>';
            }
            wp_mail( $email, $subject, $body, [ 'Content-Type: text/html; charset=UTF-8' ] );
        }

        wp_safe_redirect( add_query_arg( [
            'post_type'          => 'shop_coupon',
            'page'               => 'kdna-sc-send-credit',
            'kdna_sc_credit_sent' => 1,
        ], admin_url( 'edit.php' ) ) );
        exit;
    }

    // ---- Sample CSV Download ----

    public static function ajax_sample_csv() {
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=sample-coupons.csv' );
        $output = fopen( 'php://output', 'w' );
        fputcsv( $output, [ 'code', 'discount_type', 'amount', 'description', 'free_shipping', 'expiry_date', 'individual_use', 'usage_limit', 'usage_limit_per_user', 'minimum_amount', 'maximum_amount', 'email_restrictions', 'product_ids', 'product_categories' ] );
        fputcsv( $output, [ 'SAMPLE10OFF', 'percent', '10', 'Sample 10% off coupon', 'no', '2026-12-31', 'no', '', '', '', '', '', '', '' ] );
        fputcsv( $output, [ 'CREDIT50', 'store_credit', '50', 'Store credit coupon', 'no', '', 'no', '1', '1', '', '', 'customer@example.com', '', '' ] );
        fclose( $output );
        exit;
    }

    // =========================================================================
    // Execute Coupon Actions (Add Products to Cart)
    // =========================================================================

    public function execute_coupon_actions( $coupon_code ) {
        $coupon = new WC_Coupon( $coupon_code );
        if ( ! $coupon->get_id() ) {
            return;
        }

        $product_ids = get_post_meta( $coupon->get_id(), self::META_ACTION_ADD_PRODUCTS, true );
        if ( empty( $product_ids ) || ! is_array( $product_ids ) ) {
            return;
        }

        $qty         = max( 1, absint( get_post_meta( $coupon->get_id(), self::META_ACTION_ADD_QUANTITY, true ) ) );
        $user_choose = get_post_meta( $coupon->get_id(), self::META_ACTION_USER_CAN_CHOOSE, true ) === 'yes';

        if ( $user_choose ) {
            // Store in session for frontend product chooser.
            if ( WC()->session ) {
                WC()->session->set( 'kdna_sc_action_choose_products', $product_ids );
                WC()->session->set( 'kdna_sc_action_choose_coupon', $coupon->get_id() );
            }
            return;
        }

        // Action discount settings.
        $action_discount_amount = (float) get_post_meta( $coupon->get_id(), self::META_ACTION_DISCOUNT_AMOUNT, true );
        $action_discount_type   = get_post_meta( $coupon->get_id(), self::META_ACTION_DISCOUNT_TYPE, true );

        $added_keys = [];
        foreach ( $product_ids as $product_id ) {
            $product = wc_get_product( $product_id );
            if ( ! $product || ! $product->is_in_stock() ) {
                continue;
            }
            $cart_item_key = WC()->cart->add_to_cart( $product_id, $qty );
            if ( $cart_item_key ) {
                $added_keys[] = $cart_item_key;
            }
        }

        // Apply action discount to auto-added items by adjusting their prices.
        if ( $action_discount_amount > 0 && ! empty( $added_keys ) && ! empty( $action_discount_type ) ) {
            foreach ( $added_keys as $key ) {
                $cart_item = WC()->cart->get_cart_item( $key );
                if ( ! $cart_item || ! isset( $cart_item['data'] ) ) {
                    continue;
                }
                $product       = $cart_item['data'];
                $original_price = (float) $product->get_price();
                $new_price     = $original_price;

                if ( $action_discount_type === 'percent' ) {
                    $new_price = $original_price - ( $original_price * ( $action_discount_amount / 100 ) );
                } elseif ( $action_discount_type === 'fixed' ) {
                    $new_price = $original_price - $action_discount_amount;
                } elseif ( $action_discount_type === 'free' ) {
                    $new_price = 0;
                }

                $product->set_price( max( 0, $new_price ) );

                // Mark the cart item so we can re-apply the discount on recalculation.
                WC()->cart->cart_contents[ $key ]['_kdna_sc_action_discount'] = [
                    'amount'         => $action_discount_amount,
                    'type'           => $action_discount_type,
                    'original_price' => $original_price,
                ];
            }
        }

        // Display action message.
        $message = get_post_meta( $coupon->get_id(), self::META_ACTION_MESSAGE, true );
        if ( $message ) {
            wc_add_notice( wp_kses_post( $message ), 'success' );
        }
    }

    /**
     * Re-apply action discounts to auto-added products during cart recalculation.
     * Hooked to woocommerce_before_calculate_totals.
     */
    public function reapply_action_discounts( $cart ) {
        if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
            return;
        }
        foreach ( $cart->get_cart() as $key => $item ) {
            if ( empty( $item['_kdna_sc_action_discount'] ) ) {
                continue;
            }
            $disc           = $item['_kdna_sc_action_discount'];
            $original_price = (float) $disc['original_price'];
            $new_price      = $original_price;

            if ( $disc['type'] === 'percent' ) {
                $new_price = $original_price - ( $original_price * ( $disc['amount'] / 100 ) );
            } elseif ( $disc['type'] === 'fixed' ) {
                $new_price = $original_price - $disc['amount'];
            } elseif ( $disc['type'] === 'free' ) {
                $new_price = 0;
            }

            $item['data']->set_price( max( 0, $new_price ) );
        }
    }

    // =========================================================================
    // Admin — Product Fields (Attach Coupon to Product)
    // =========================================================================

    public function add_product_coupon_fields() {
        global $post;
        echo '<div class="options_group">';
        woocommerce_wp_text_input( [
            'id'          => self::META_PRODUCT_COUPONS,
            'label'       => __( 'Coupons (Smart Coupons)', 'kdna-ecommerce' ),
            'description' => __( 'Comma-separated coupon codes to issue when this product is purchased.', 'kdna-ecommerce' ),
            'desc_tip'    => true,
            'value'       => get_post_meta( $post->ID, self::META_PRODUCT_COUPONS, true ),
        ] );

        woocommerce_wp_checkbox( [
            'id'          => self::META_PRODUCT_GIFT_IMAGE,
            'label'       => __( 'Gift card image upload', 'kdna-ecommerce' ),
            'description' => __( 'Allow customers to upload a custom gift card image.', 'kdna-ecommerce' ),
            'value'       => get_post_meta( $post->ID, self::META_PRODUCT_GIFT_IMAGE, true ),
            'cbvalue'     => 'yes',
        ] );
        echo '</div>';
    }

    public function save_product_coupon_fields( $post_id ) {
        if ( isset( $_POST[ self::META_PRODUCT_COUPONS ] ) ) {
            update_post_meta( $post_id, self::META_PRODUCT_COUPONS, sanitize_text_field( wp_unslash( $_POST[ self::META_PRODUCT_COUPONS ] ) ) );
        }
        update_post_meta( $post_id, self::META_PRODUCT_GIFT_IMAGE, isset( $_POST[ self::META_PRODUCT_GIFT_IMAGE ] ) ? 'yes' : 'no' );
    }

    // =========================================================================
    // Store Credit Discount Type
    // =========================================================================

    public function add_store_credit_type( $types ) {
        $s = self::get_settings();
        $label = $s['credit_label_singular'] ?: 'Store Credit';
        $types['store_credit'] = sprintf( __( '%s / Gift Certificate', 'kdna-ecommerce' ), $label );
        return $types;
    }

    public function store_credit_discount_amount( $discount, $discounting_amount, $cart_item, $single, $coupon ) {
        if ( $coupon->get_discount_type() !== 'store_credit' ) {
            return $discount;
        }
        return min( $coupon->get_amount(), $discounting_amount );
    }

    public function apply_before_tax( $discount, $discounting_amount, $cart_item, $single, $coupon ) {
        if ( $coupon->get_discount_type() !== 'store_credit' ) {
            return $discount;
        }

        // When prices do NOT include tax, the discount should apply to the
        // item price + tax so the store credit covers the full cost.
        if ( ! wc_prices_include_tax() && $cart_item && isset( $cart_item['data'] ) ) {
            $product = $cart_item['data'];
            if ( $product && wc_tax_enabled() ) {
                $tax_rates   = WC_Tax::get_rates( $product->get_tax_class() );
                $item_taxes  = WC_Tax::calc_tax( $discounting_amount, $tax_rates, false );
                $tax_amount  = array_sum( $item_taxes );
                // Increase the discount to cover the tax portion.
                $discount = min( $coupon->get_amount(), $discounting_amount + $tax_amount );
            }
        }

        return $discount;
    }

    // =========================================================================
    // Order Processing — Deduct Credit, Auto-Generate, Cashback
    // =========================================================================

    public function process_order_coupons( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order || $order->get_meta( '_kdna_sc_credits_deducted' ) === 'yes' ) {
            return;
        }
        foreach ( $order->get_coupon_codes() as $code ) {
            $coupon = new WC_Coupon( $code );
            if ( $coupon->get_discount_type() !== 'store_credit' ) {
                continue;
            }
            foreach ( $order->get_items( 'coupon' ) as $item ) {
                if ( $item->get_code() !== $code ) {
                    continue;
                }
                $used      = (float) $item->get_discount();
                $remaining = max( 0, $coupon->get_amount() - $used );
                $coupon->set_amount( $remaining );
                $coupon->save();
            }
        }
        $order->update_meta_data( '_kdna_sc_credits_deducted', 'yes' );
        $order->save();
    }

    public function auto_generate_coupons_for_order( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order || $order->get_meta( '_kdna_sc_coupons_generated' ) === 'yes' ) {
            return;
        }

        $settings = self::get_settings();

        foreach ( $order->get_items() as $item ) {
            $product_id = $item->get_product_id();
            $coupon_titles = get_post_meta( $product_id, self::META_PRODUCT_COUPONS, true );
            if ( empty( $coupon_titles ) ) {
                continue;
            }

            $codes = array_map( 'trim', explode( ',', $coupon_titles ) );
            foreach ( $codes as $template_code ) {
                $template = new WC_Coupon( $template_code );
                if ( ! $template->get_id() ) {
                    continue;
                }
                if ( get_post_meta( $template->get_id(), self::META_AUTO_GENERATE, true ) !== 'yes' ) {
                    continue;
                }

                $qty = $item->get_quantity();
                for ( $i = 0; $i < $qty; $i++ ) {
                    $new_code = $this->generate_coupon_code( $template->get_id(), $settings );
                    $new_coupon = $this->clone_coupon( $template, $new_code, $order, $item );
                    if ( $new_coupon ) {
                        $order->add_order_note(
                            sprintf( __( 'Coupon %s generated from template %s.', 'kdna-ecommerce' ), $new_code, $template_code )
                        );
                        do_action( 'kdna_sc_coupon_generated', $new_coupon, $order, $template );
                    }
                }
            }
        }

        $order->update_meta_data( '_kdna_sc_coupons_generated', 'yes' );
        $order->save();
    }

    private function generate_coupon_code( $template_id, $settings ) {
        $length = (int) ( $settings['coupon_code_length'] ?: 13 );
        $prefix = get_post_meta( $template_id, self::META_COUPON_PREFIX, true );
        $suffix = get_post_meta( $template_id, self::META_COUPON_SUFFIX, true );

        $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $code  = '';
        for ( $i = 0; $i < $length; $i++ ) {
            $code .= $chars[ wp_rand( 0, strlen( $chars ) - 1 ) ];
        }
        return strtolower( $prefix . $code . $suffix );
    }

    private function clone_coupon( $template, $new_code, $order, $item ) {
        $new = new WC_Coupon();
        $new->set_code( $new_code );
        $new->set_discount_type( $template->get_discount_type() );

        if ( get_post_meta( $template->get_id(), self::META_PICK_PRICE_OF_PRODUCT, true ) === 'yes' ) {
            $new->set_amount( (float) $item->get_total() / max( 1, $item->get_quantity() ) );
        } else {
            $new->set_amount( $template->get_amount() );
        }

        $new->set_individual_use( $template->get_individual_use() );
        $new->set_product_ids( $template->get_product_ids() );
        $new->set_excluded_product_ids( $template->get_excluded_product_ids() );
        $new->set_usage_limit( $template->get_usage_limit() );
        $new->set_usage_limit_per_user( $template->get_usage_limit_per_user() );
        $new->set_limit_usage_to_x_items( $template->get_limit_usage_to_x_items() );
        $new->set_free_shipping( $template->get_free_shipping() );
        $new->set_product_categories( $template->get_product_categories() );
        $new->set_excluded_product_categories( $template->get_excluded_product_categories() );
        $new->set_exclude_sale_items( $template->get_exclude_sale_items() );
        $new->set_minimum_amount( $template->get_minimum_amount() );
        $new->set_maximum_amount( $template->get_maximum_amount() );
        $new->set_description( $template->get_description() );

        // Email restriction.
        $disable_email = get_post_meta( $template->get_id(), self::META_DISABLE_EMAIL_RESTRICT, true );
        if ( $disable_email !== 'yes' ) {
            $new->set_email_restrictions( [ $order->get_billing_email() ] );
        }

        // Validity.
        $validity = (int) get_post_meta( $template->get_id(), self::META_COUPON_VALIDITY, true );
        if ( $validity > 0 ) {
            $unit = get_post_meta( $template->get_id(), self::META_VALIDITY_UNIT, true ) ?: 'days';
            $expiry = new WC_DateTime();
            $expiry->modify( "+{$validity} {$unit}" );

            // Apply expiry time if set on the template.
            $expiry_time = get_post_meta( $template->get_id(), self::META_EXPIRY_TIME, true );
            if ( $expiry_time && preg_match( '/^\d{1,2}:\d{2}$/', $expiry_time ) ) {
                list( $h, $m ) = explode( ':', $expiry_time );
                $expiry->setTime( absint( $h ), absint( $m ), 0 );
            }

            $new->set_date_expires( $expiry );
        }

        $new->save();

        update_post_meta( $new->get_id(), self::META_ORDER_GENERATED, $order->get_id() );
        return $new;
    }

    // ---- Cashback ----

    public function process_cashback_reward( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order || $order->get_meta( self::META_CASHBACK_ELIGIBLE ) === 'processed' ) {
            return;
        }

        $s = self::get_settings();
        $min = (float) $s['cashback_min_order'];
        if ( $min > 0 && $order->get_total() < $min ) {
            return;
        }

        $amount = (float) $s['cashback_amount'];
        if ( $amount <= 0 ) {
            return;
        }
        if ( $s['cashback_type'] === 'percentage' ) {
            $amount = $order->get_total() * ( $amount / 100 );
        }

        $template_id = (int) $s['cashback_template_coupon'];
        $code = $this->generate_coupon_code( $template_id ?: 0, $s );

        $coupon = new WC_Coupon();
        $coupon->set_code( $code );
        $coupon->set_discount_type( 'store_credit' );
        $coupon->set_amount( round( $amount, 2 ) );
        $coupon->set_email_restrictions( [ $order->get_billing_email() ] );
        $coupon->set_usage_limit( 1 );

        if ( $template_id ) {
            $template = new WC_Coupon( $template_id );
            if ( $template->get_id() ) {
                $coupon->set_description( $template->get_description() );
            }
        }

        $coupon->save();
        $order->update_meta_data( self::META_CASHBACK_ELIGIBLE, 'processed' );
        $order->add_order_note( sprintf( __( 'Cashback coupon %s generated for %s.', 'kdna-ecommerce' ), $code, wc_price( $amount ) ) );
        $order->save();

        do_action( 'kdna_sc_coupon_generated', $coupon, $order, null );
    }

    // ---- Delete used credit ----

    public function maybe_delete_used_credit( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }
        foreach ( $order->get_coupon_codes() as $code ) {
            $coupon = new WC_Coupon( $code );
            if ( $coupon->get_discount_type() === 'store_credit' && $coupon->get_amount() <= 0 ) {
                wp_trash_post( $coupon->get_id() );
            }
        }
    }

    // =========================================================================
    // Coupon Emails
    // =========================================================================

    public function register_email_classes( $emails ) {
        $path = KDNA_ECOMMERCE_PATH . 'modules/smart-coupons/emails/';
        if ( file_exists( $path . 'class-kdna-sc-email-coupon.php' ) ) {
            require_once $path . 'class-kdna-sc-email-coupon.php';
            $emails['KDNA_SC_Email_Coupon'] = new KDNA_SC_Email_Coupon();
        }
        return $emails;
    }

    public function send_coupon_email( $coupon, $order, $template ) {
        $s = self::get_settings();
        if ( $s['send_coupon_email'] !== 'yes' ) {
            return;
        }

        $to = $order->get_billing_email();
        $subject = sprintf( __( 'You have received a coupon: %s', 'kdna-ecommerce' ), $coupon->get_code() );
        $message = $this->build_coupon_email_html( $coupon, $order );

        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        wp_mail( $to, $subject, $message, $headers );
    }

    private function build_coupon_email_html( $coupon, $order ) {
        $s        = self::get_settings();
        $bg       = $s['custom_bg_color'] ?: '#39cccc';
        $fg       = $s['custom_fg_color'] ?: '#30050b';
        $third    = $s['custom_third_color'] ?: $bg;
        $design   = $s['coupon_email_design'] ?: 'email-coupon';
        $code     = strtoupper( $coupon->get_code() );
        $amount_text = $coupon->get_discount_type() === 'percent'
            ? round( $coupon->get_amount() ) . '%'
            : wp_strip_all_tags( wc_price( $coupon->get_amount() ) );

        ob_start();
        ?>
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">
            <h2 style="text-align:center;"><?php esc_html_e( 'You have received a coupon!', 'kdna-ecommerce' ); ?></h2>

            <?php if ( $design === 'email-coupon-minimal' ) : ?>
                <!-- Minimal design -->
                <div style="border:1px solid <?php echo esc_attr( $bg ); ?>;border-radius:8px;padding:25px;text-align:center;">
                    <p style="font-size:28px;font-weight:bold;margin:0;color:<?php echo esc_attr( $fg ); ?>;">
                        <?php echo esc_html( $amount_text ); ?> <?php esc_html_e( 'OFF', 'kdna-ecommerce' ); ?>
                    </p>
                    <p style="font-family:monospace;font-size:20px;margin:12px 0;padding:10px;background:#f7f7f7;border-radius:4px;letter-spacing:3px;"><?php echo esc_html( $code ); ?></p>
                    <?php if ( $coupon->get_date_expires() ) : ?>
                        <p style="font-size:12px;color:#999;margin:5px 0;"><?php printf( esc_html__( 'Valid until %s', 'kdna-ecommerce' ), esc_html( $coupon->get_date_expires()->date_i18n( wc_date_format() ) ) ); ?></p>
                    <?php endif; ?>
                </div>

            <?php elseif ( $design === 'email-coupon-banner' ) : ?>
                <!-- Banner design -->
                <div style="background:<?php echo esc_attr( $bg ); ?>;color:<?php echo esc_attr( $fg ); ?>;padding:30px 20px;border-radius:8px;text-align:center;position:relative;overflow:hidden;">
                    <div style="position:relative;z-index:1;">
                        <p style="font-size:14px;margin:0 0 5px;text-transform:uppercase;opacity:0.8;"><?php esc_html_e( 'Your exclusive discount', 'kdna-ecommerce' ); ?></p>
                        <p style="font-size:36px;font-weight:bold;margin:0;">
                            <?php echo esc_html( $amount_text ); ?> <?php esc_html_e( 'OFF', 'kdna-ecommerce' ); ?>
                        </p>
                        <p style="font-family:monospace;font-size:20px;margin:15px 0;padding:10px 20px;background:rgba(255,255,255,0.2);border-radius:4px;display:inline-block;letter-spacing:3px;"><?php echo esc_html( $code ); ?></p>
                        <?php if ( $coupon->get_date_expires() ) : ?>
                            <p style="font-size:12px;margin:10px 0 0;opacity:0.8;"><?php printf( esc_html__( 'Expires: %s', 'kdna-ecommerce' ), esc_html( $coupon->get_date_expires()->date_i18n( wc_date_format() ) ) ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

            <?php elseif ( $design === 'email-coupon-ticket' ) : ?>
                <!-- Ticket / dashed-border design -->
                <div style="border:3px dashed <?php echo esc_attr( $bg ); ?>;border-radius:12px;padding:25px;text-align:center;background:<?php echo esc_attr( $third ); ?>15;">
                    <p style="font-size:14px;color:<?php echo esc_attr( $bg ); ?>;text-transform:uppercase;font-weight:bold;margin:0 0 8px;"><?php esc_html_e( 'Coupon Code', 'kdna-ecommerce' ); ?></p>
                    <p style="font-family:monospace;font-size:24px;font-weight:bold;margin:0;color:<?php echo esc_attr( $fg ); ?>;letter-spacing:3px;"><?php echo esc_html( $code ); ?></p>
                    <hr style="border:none;border-top:1px dashed <?php echo esc_attr( $bg ); ?>;margin:15px 0;" />
                    <p style="font-size:20px;font-weight:bold;margin:0;color:<?php echo esc_attr( $fg ); ?>;">
                        <?php echo esc_html( $amount_text ); ?> <?php esc_html_e( 'DISCOUNT', 'kdna-ecommerce' ); ?>
                    </p>
                    <?php if ( $coupon->get_date_expires() ) : ?>
                        <p style="font-size:12px;color:#999;margin:10px 0 0;"><?php printf( esc_html__( 'Expires: %s', 'kdna-ecommerce' ), esc_html( $coupon->get_date_expires()->date_i18n( wc_date_format() ) ) ); ?></p>
                    <?php endif; ?>
                </div>

            <?php else : ?>
                <!-- Default design (email-coupon) -->
                <div style="background:<?php echo esc_attr( $bg ); ?>;color:<?php echo esc_attr( $fg ); ?>;padding:20px;border-radius:8px;text-align:center;">
                    <p style="font-size:24px;font-weight:bold;margin:0;">
                        <?php echo esc_html( $amount_text ); ?>
                        <?php esc_html_e( 'DISCOUNT', 'kdna-ecommerce' ); ?>
                    </p>
                    <p style="font-family:monospace;font-size:18px;margin:10px 0;"><?php echo esc_html( $code ); ?></p>
                    <?php if ( $coupon->get_date_expires() ) : ?>
                        <p style="font-size:12px;margin:5px 0;"><?php printf( esc_html__( 'Expires: %s', 'kdna-ecommerce' ), esc_html( $coupon->get_date_expires()->date_i18n( wc_date_format() ) ) ); ?></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php
            // Coupon message.
            $msg = get_post_meta( $coupon->get_id(), self::META_COUPON_MESSAGE, true );
            if ( $msg ) {
                echo '<div style="margin-top:15px;">' . wp_kses_post( $msg ) . '</div>';
            }

            // Action message — include in email if the setting is enabled.
            $include_action = get_post_meta( $coupon->get_id(), self::META_ACTION_INCLUDE_IN_EMAIL, true );
            if ( $include_action === 'yes' ) {
                $action_msg = get_post_meta( $coupon->get_id(), self::META_ACTION_MESSAGE, true );
                if ( $action_msg ) {
                    echo '<div style="margin-top:15px;padding:15px;background:#f0f9ff;border-left:4px solid ' . esc_attr( $bg ) . ';border-radius:4px;">';
                    echo wp_kses_post( $action_msg );
                    echo '</div>';
                }

                // Show the products that will be added to cart.
                $action_products = get_post_meta( $coupon->get_id(), self::META_ACTION_ADD_PRODUCTS, true );
                if ( ! empty( $action_products ) && is_array( $action_products ) ) {
                    echo '<div style="margin-top:10px;font-size:13px;color:#666;">';
                    echo '<strong>' . esc_html__( 'Included products:', 'kdna-ecommerce' ) . '</strong> ';
                    $names = [];
                    foreach ( $action_products as $pid ) {
                        $p = wc_get_product( $pid );
                        if ( $p ) {
                            $names[] = $p->get_name();
                        }
                    }
                    echo esc_html( implode( ', ', $names ) );
                    echo '</div>';
                }
            }
            ?>
        </div>
        <?php
        return ob_get_clean();
    }

    // =========================================================================
    // Expiry & Unused Reminders
    // =========================================================================

    public function send_expiry_reminders() {
        $s   = self::get_settings();
        $days = (int) $s['expiry_reminder_days_before'];
        if ( $days <= 0 ) {
            return;
        }

        $target_date = gmdate( 'Y-m-d', strtotime( "+{$days} days" ) );
        $coupons = get_posts( [
            'post_type'      => 'shop_coupon',
            'post_status'    => 'publish',
            'posts_per_page' => 100,
            'meta_query'     => [
                [
                    'key'     => 'date_expires',
                    'value'   => strtotime( $target_date ),
                    'compare' => '<=',
                    'type'    => 'NUMERIC',
                ],
                [
                    'key'     => 'date_expires',
                    'value'   => time(),
                    'compare' => '>',
                    'type'    => 'NUMERIC',
                ],
            ],
            'fields' => 'ids',
        ] );

        foreach ( $coupons as $coupon_id ) {
            if ( get_post_meta( $coupon_id, '_kdna_sc_expiry_reminder_sent', true ) === 'yes' ) {
                continue;
            }
            $coupon = new WC_Coupon( $coupon_id );
            $emails = $coupon->get_email_restrictions();
            if ( empty( $emails ) ) {
                continue;
            }
            foreach ( $emails as $email ) {
                $subject = sprintf( __( 'Your coupon %s is expiring soon!', 'kdna-ecommerce' ), $coupon->get_code() );
                $body = sprintf(
                    __( 'Your coupon code <strong>%s</strong> expires on %s. Use it before it\'s gone!', 'kdna-ecommerce' ),
                    strtoupper( $coupon->get_code() ),
                    $coupon->get_date_expires()->date_i18n( wc_date_format() )
                );
                wp_mail( $email, $subject, $body, [ 'Content-Type: text/html; charset=UTF-8' ] );
            }
            update_post_meta( $coupon_id, '_kdna_sc_expiry_reminder_sent', 'yes' );
        }
    }

    public function send_unused_reminders() {
        $s         = self::get_settings();
        $days      = (int) $s['unused_reminder_days'];
        $max       = (int) $s['unused_max_reminders'];
        $threshold = gmdate( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );

        $coupons = get_posts( [
            'post_type'      => 'shop_coupon',
            'post_status'    => 'publish',
            'posts_per_page' => 100,
            'date_query'     => [ [ 'before' => $threshold ] ],
            'meta_query'     => [
                [
                    'key'     => 'usage_count',
                    'value'   => '0',
                    'compare' => '=',
                ],
            ],
            'fields' => 'ids',
        ] );

        foreach ( $coupons as $coupon_id ) {
            $sent_count = (int) get_post_meta( $coupon_id, '_kdna_sc_unused_reminder_count', true );
            if ( $sent_count >= $max ) {
                continue;
            }
            $coupon = new WC_Coupon( $coupon_id );
            $emails = $coupon->get_email_restrictions();
            if ( empty( $emails ) ) {
                continue;
            }
            foreach ( $emails as $email ) {
                $subject = sprintf( __( 'Don\'t forget your coupon %s!', 'kdna-ecommerce' ), $coupon->get_code() );
                $body = sprintf(
                    __( 'You have an unused coupon <strong>%s</strong> worth %s. Use it on your next order!', 'kdna-ecommerce' ),
                    strtoupper( $coupon->get_code() ),
                    $coupon->get_discount_type() === 'percent' ? round( $coupon->get_amount() ) . '%' : wc_price( $coupon->get_amount() )
                );
                wp_mail( $email, $subject, $body, [ 'Content-Type: text/html; charset=UTF-8' ] );
            }
            update_post_meta( $coupon_id, '_kdna_sc_unused_reminder_count', $sent_count + 1 );
        }
    }

    // =========================================================================
    // Coupon Printing
    // =========================================================================

    public function ajax_print_coupon() {
        $coupon_id = isset( $_GET['coupon_id'] ) ? absint( $_GET['coupon_id'] ) : 0;
        if ( ! $coupon_id ) {
            wp_die( __( 'Invalid coupon.', 'kdna-ecommerce' ) );
        }
        $coupon = new WC_Coupon( $coupon_id );
        $s      = self::get_settings();
        ?>
        <!DOCTYPE html>
        <html>
        <head><title><?php esc_html_e( 'Print Coupon', 'kdna-ecommerce' ); ?></title>
        <style>
            body { font-family: Arial, sans-serif; text-align: center; padding: 40px; }
            .coupon-print { display: inline-block; padding: 30px 50px; border: 3px dashed <?php echo esc_attr( $s['custom_bg_color'] ); ?>; border-radius: 12px; }
            .coupon-amount { font-size: 36px; font-weight: bold; color: <?php echo esc_attr( $s['custom_bg_color'] ); ?>; }
            .coupon-code { font-family: monospace; font-size: 24px; margin: 15px 0; letter-spacing: 2px; }
            .coupon-expiry { font-size: 14px; color: #999; }
            @media print { .no-print { display: none; } }
        </style>
        </head>
        <body>
        <div class="coupon-print">
            <div class="coupon-amount">
                <?php echo $coupon->get_discount_type() === 'percent' ? round( $coupon->get_amount() ) . '% OFF' : wc_price( $coupon->get_amount() ) . ' OFF'; ?>
            </div>
            <div class="coupon-code"><?php echo esc_html( strtoupper( $coupon->get_code() ) ); ?></div>
            <?php if ( $coupon->get_date_expires() ) : ?>
                <div class="coupon-expiry"><?php printf( esc_html__( 'Valid until %s', 'kdna-ecommerce' ), esc_html( $coupon->get_date_expires()->date_i18n( wc_date_format() ) ) ); ?></div>
            <?php endif; ?>
            <?php if ( $coupon->get_description() ) : ?>
                <p><?php echo esc_html( $coupon->get_description() ); ?></p>
            <?php endif; ?>
        </div>
        <p class="no-print"><button onclick="window.print()"><?php esc_html_e( 'Print', 'kdna-ecommerce' ); ?></button></p>
        </body></html>
        <?php
        exit;
    }

    // =========================================================================
    // Send Coupon Form (Gift to Others at Checkout)
    // =========================================================================

    public function render_send_coupon_form( $checkout ) {
        $s = self::get_settings();
        // Only show if cart has products that issue coupons.
        $has_coupon_products = false;
        foreach ( WC()->cart->get_cart() as $item ) {
            $titles = get_post_meta( $item['product_id'], self::META_PRODUCT_COUPONS, true );
            if ( ! empty( $titles ) ) {
                $has_coupon_products = true;
                break;
            }
        }
        if ( ! $has_coupon_products ) {
            return;
        }
        ?>
        <div id="kdna-sc-send-coupon-form" class="kdna-sc-send-form">
            <h3><?php echo esc_html( $s['send_form_title'] ); ?></h3>
            <?php if ( $s['send_form_description'] ) : ?>
                <p><?php echo esc_html( $s['send_form_description'] ); ?></p>
            <?php endif; ?>
            <p class="form-row form-row-wide">
                <label for="kdna_sc_gift_email"><?php esc_html_e( 'Recipient Email', 'kdna-ecommerce' ); ?></label>
                <input type="email" name="kdna_sc_gift_email" id="kdna_sc_gift_email" class="input-text" placeholder="<?php esc_attr_e( 'Enter email address', 'kdna-ecommerce' ); ?>">
            </p>
            <p class="form-row form-row-wide">
                <label for="kdna_sc_gift_message"><?php esc_html_e( 'Personal Message (optional)', 'kdna-ecommerce' ); ?></label>
                <textarea name="kdna_sc_gift_message" id="kdna_sc_gift_message" class="input-text" rows="3" placeholder="<?php esc_attr_e( 'Add a personal message...', 'kdna-ecommerce' ); ?>"></textarea>
            </p>
            <?php if ( $s['allow_schedule_sending'] === 'yes' ) : ?>
                <p class="form-row form-row-wide">
                    <label for="kdna_sc_gift_date"><?php esc_html_e( 'Send Date (optional)', 'kdna-ecommerce' ); ?></label>
                    <input type="datetime-local" name="kdna_sc_gift_date" id="kdna_sc_gift_date" class="input-text">
                </p>
            <?php endif; ?>
        </div>
        <?php
    }

    public function save_send_coupon_form( $order_id ) {
        if ( ! empty( $_POST['kdna_sc_gift_email'] ) ) {
            $order = wc_get_order( $order_id );
            $order->update_meta_data( self::META_GIFT_EMAIL, sanitize_email( wp_unslash( $_POST['kdna_sc_gift_email'] ) ) );
            if ( ! empty( $_POST['kdna_sc_gift_message'] ) ) {
                $order->update_meta_data( self::META_GIFT_MESSAGE, sanitize_textarea_field( wp_unslash( $_POST['kdna_sc_gift_message'] ) ) );
            }
            if ( ! empty( $_POST['kdna_sc_gift_date'] ) ) {
                $order->update_meta_data( self::META_GIFT_TIMESTAMP, sanitize_text_field( wp_unslash( $_POST['kdna_sc_gift_date'] ) ) );
            }
            $order->save();
        }
    }

    // =========================================================================
    // Store Notice Banner
    // =========================================================================

    public function store_notice_coupon( $notice, $raw_notice ) {
        $s    = self::get_settings();
        $code = $s['storewide_coupon_code'];
        if ( empty( $code ) ) {
            return $notice;
        }
        $coupon = new WC_Coupon( $code );
        if ( ! $coupon->get_id() ) {
            return $notice;
        }
        $discount = $coupon->get_discount_type() === 'percent'
            ? round( $coupon->get_amount() ) . '% off'
            : wc_price( $coupon->get_amount() ) . ' off';
        $link = home_url( '/?apply_coupon=' . $code );
        return '<a href="' . esc_url( $link ) . '">' . sprintf( __( 'Use code <strong>%1$s</strong> for %2$s!', 'kdna-ecommerce' ), strtoupper( $code ), $discount ) . '</a>';
    }

    // =========================================================================
    // My Account — Coupons Endpoint
    // =========================================================================

    public function register_myaccount_endpoint() {
        add_rewrite_endpoint( 'coupons', EP_ROOT | EP_PAGES );
    }

    public function myaccount_menu_item( $items ) {
        $s = self::get_settings();
        if ( $s['show_on_myaccount'] !== 'yes' ) {
            return $items;
        }
        $new_items = [];
        foreach ( $items as $key => $label ) {
            $new_items[ $key ] = $label;
            if ( $key === 'orders' ) {
                $new_items['coupons'] = $s['credit_label_plural'] ?: __( 'Coupons', 'kdna-ecommerce' );
            }
        }
        return $new_items;
    }

    public function myaccount_coupons_page() {
        $s       = self::get_settings();
        $coupons = $this->get_available_coupons();
        $design  = $s['coupon_design'];
        $bg      = $s['custom_bg_color'];
        $fg      = $s['custom_fg_color'];

        echo '<h3>' . esc_html( $s['myaccount_label'] ) . '</h3>';

        if ( empty( $coupons ) ) {
            echo '<p>' . esc_html__( 'No coupons available.', 'kdna-ecommerce' ) . '</p>';
            return;
        }

        echo '<div class="kdna-sc-available-coupons kdna-sc-myaccount">';
        echo '<div class="kdna-sc-coupon-grid kdna-sc-design-' . esc_attr( $design ) . '">';
        foreach ( $coupons as $coupon ) {
            $this->render_coupon_card( $coupon, $design, $bg, $fg, false );
        }
        echo '</div></div>';

        // Show invalid/used coupons if setting enabled.
        if ( $s['show_invalid_on_myaccount'] === 'yes' ) {
            $this->display_invalid_coupons();
        }
    }

    private function display_invalid_coupons() {
        $user_id = get_current_user_id();
        if ( ! $user_id ) {
            return;
        }
        $user  = get_userdata( $user_id );
        $email = $user ? $user->user_email : '';

        $expired = get_posts( [
            'post_type'      => 'shop_coupon',
            'post_status'    => 'publish',
            'posts_per_page' => 20,
            'meta_query'     => [
                'relation' => 'AND',
                [
                    'key'     => '_email_restrictions',
                    'value'   => $email,
                    'compare' => 'LIKE',
                ],
                [
                    'key'     => 'date_expires',
                    'value'   => time(),
                    'compare' => '<',
                    'type'    => 'NUMERIC',
                ],
            ],
            'fields' => 'ids',
        ] );

        if ( empty( $expired ) ) {
            return;
        }

        echo '<h4 style="margin-top:20px;opacity:0.6;">' . esc_html__( 'Expired / Used Coupons', 'kdna-ecommerce' ) . '</h4>';
        echo '<div class="kdna-sc-coupon-grid" style="opacity:0.5;">';
        foreach ( $expired as $id ) {
            $coupon = new WC_Coupon( $id );
            $this->render_coupon_card( $coupon, 'minimal', '#999', '#333', false );
        }
        echo '</div>';
    }

    // =========================================================================
    // Display Available Coupons
    // =========================================================================

    public function display_available_coupons_cart() {
        $this->display_available_coupons( 'cart' );
    }

    public function display_available_coupons_checkout() {
        $this->display_available_coupons( 'checkout' );
    }

    public function display_available_coupons( $context = 'cart' ) {
        $s       = self::get_settings();
        $coupons = $this->get_available_coupons();

        if ( empty( $coupons ) && $s['always_show_section'] !== 'yes' ) {
            return;
        }

        $design = $s['coupon_design'];
        $bg     = $s['custom_bg_color'];
        $fg     = $s['custom_fg_color'];
        $label  = $s['cart_checkout_label'];
        $label  = str_replace( '{coupons_count}', count( $coupons ), $label );
        $open   = $s['default_section_open'] === 'yes' ? ' open' : '';

        echo '<div class="kdna-sc-available-coupons">';
        echo '<details' . $open . '>';
        echo '<summary class="kdna-sc-heading">' . esc_html( $label ) . '</summary>';
        if ( ! empty( $coupons ) ) {
            echo '<div class="kdna-sc-coupon-grid kdna-sc-design-' . esc_attr( $design ) . '">';
            foreach ( $coupons as $coupon ) {
                $this->render_coupon_card( $coupon, $design, $bg, $fg );
            }
            echo '</div>';
        } else {
            echo '<p>' . esc_html__( 'No coupons available.', 'kdna-ecommerce' ) . '</p>';
        }
        echo '</details></div>';
    }

    public function display_myaccount_coupons() {
        $s       = self::get_settings();
        $coupons = $this->get_available_coupons();
        if ( empty( $coupons ) ) {
            return;
        }
        $design = $s['coupon_design'];
        $bg     = $s['custom_bg_color'];
        $fg     = $s['custom_fg_color'];

        echo '<div class="kdna-sc-available-coupons kdna-sc-myaccount">';
        echo '<h3 class="kdna-sc-heading">' . esc_html( $s['myaccount_label'] ) . '</h3>';
        echo '<div class="kdna-sc-coupon-grid kdna-sc-design-' . esc_attr( $design ) . '">';
        foreach ( $coupons as $coupon ) {
            $this->render_coupon_card( $coupon, $design, $bg, $fg, false );
        }
        echo '</div></div>';
    }

    public function display_product_coupons() {
        global $product;
        if ( ! $product ) {
            return;
        }
        $titles = get_post_meta( $product->get_id(), self::META_PRODUCT_COUPONS, true );
        if ( empty( $titles ) ) {
            return;
        }
        $s     = self::get_settings();
        $codes = array_map( 'trim', explode( ',', $titles ) );

        echo '<div class="kdna-sc-product-coupons">';
        echo '<p class="kdna-sc-product-text">' . esc_html( $s['coupons_with_product_text'] ) . '</p>';
        echo '<div class="kdna-sc-coupon-grid kdna-sc-design-' . esc_attr( $s['coupon_design'] ) . '">';
        foreach ( $codes as $code ) {
            $coupon = new WC_Coupon( $code );
            if ( $coupon->get_id() ) {
                $this->render_coupon_card( $coupon, $s['coupon_design'], $s['custom_bg_color'], $s['custom_fg_color'], false );
            }
        }
        echo '</div></div>';
    }

    // ---- Discounted Price Display ----

    public function display_discounted_price( $price, $cart_item, $cart_item_key ) {
        $applied = WC()->cart->get_applied_coupons();
        if ( empty( $applied ) ) {
            return $price;
        }
        $product = $cart_item['data'];
        $original = (float) $product->get_price();
        $discounted = $original;

        foreach ( $applied as $code ) {
            $coupon = new WC_Coupon( $code );
            if ( $coupon->get_discount_type() === 'percent' ) {
                $discounted -= $original * ( $coupon->get_amount() / 100 );
            } elseif ( $coupon->get_discount_type() === 'fixed_product' ) {
                $discounted -= $coupon->get_amount();
            }
        }

        $discounted = max( 0, $discounted );
        if ( $discounted < $original ) {
            return '<del>' . wc_price( $original ) . '</del> <ins>' . wc_price( $discounted ) . '</ins>';
        }
        return $price;
    }

    // =========================================================================
    // Render Coupon Card
    // =========================================================================

    public function render_coupon_card( $coupon, $design = 'basic', $bg = '#39cccc', $fg = '#30050b', $show_apply = true ) {
        $s           = self::get_settings();
        $code        = $coupon->get_code();
        $amount      = $coupon->get_amount();
        $type        = $coupon->get_discount_type();
        $description = $coupon->get_description();
        $expiry      = $coupon->get_date_expires();

        switch ( $type ) {
            case 'percent':
                $display = round( $amount ) . '%';
                $label   = __( 'OFF', 'kdna-ecommerce' );
                break;
            case 'store_credit':
                $display = wc_price( $amount );
                $label   = $s['credit_label_singular'] ?: __( 'CREDIT', 'kdna-ecommerce' );
                break;
            default:
                $display = wc_price( $amount );
                $label   = __( 'OFF', 'kdna-ecommerce' );
                break;
        }

        $nonce      = wp_create_nonce( 'kdna_sc_apply_' . $code );
        $is_applied = WC()->cart && WC()->cart->has_discount( $code );
        $show_desc  = $s['show_coupon_description'] === 'yes';
        $message    = get_post_meta( $coupon->get_id(), self::META_COUPON_MESSAGE, true );
        ?>
        <div class="kdna-sc-coupon-card <?php echo $is_applied ? 'kdna-sc-applied' : ''; ?>" style="--kdna-sc-bg:<?php echo esc_attr( $bg ); ?>;--kdna-sc-fg:<?php echo esc_attr( $fg ); ?>;--kdna-sc-third:<?php echo esc_attr( $s['custom_third_color'] ); ?>;" data-code="<?php echo esc_attr( $code ); ?>">
            <div class="kdna-sc-coupon-amount">
                <span class="kdna-sc-discount"><?php echo $display; ?></span>
                <span class="kdna-sc-label"><?php echo esc_html( $label ); ?></span>
            </div>
            <div class="kdna-sc-coupon-details">
                <span class="kdna-sc-code"><?php echo esc_html( strtoupper( $code ) ); ?></span>
                <?php if ( $show_desc && $description ) : ?>
                    <span class="kdna-sc-desc"><?php echo esc_html( $description ); ?></span>
                <?php endif; ?>
                <?php if ( $message ) : ?>
                    <span class="kdna-sc-message"><?php echo wp_kses_post( $message ); ?></span>
                <?php endif; ?>
                <?php if ( $expiry ) : ?>
                    <span class="kdna-sc-expiry"><?php printf( esc_html__( 'Expires: %s', 'kdna-ecommerce' ), esc_html( $expiry->date_i18n( wc_date_format() ) ) ); ?></span>
                <?php endif; ?>
            </div>
            <div class="kdna-sc-coupon-actions">
                <?php if ( $show_apply && ! $is_applied ) : ?>
                    <button type="button" class="kdna-sc-apply-btn" data-coupon="<?php echo esc_attr( $code ); ?>" data-nonce="<?php echo esc_attr( $nonce ); ?>">
                        <?php esc_html_e( 'Apply', 'kdna-ecommerce' ); ?>
                    </button>
                <?php elseif ( $is_applied ) : ?>
                    <span class="kdna-sc-applied-badge"><?php esc_html_e( 'Applied', 'kdna-ecommerce' ); ?></span>
                <?php endif; ?>
                <?php if ( $s['enable_printing'] === 'yes' ) : ?>
                    <a href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=kdna_sc_print_coupon&coupon_id=' . $coupon->get_id() ) ); ?>" class="kdna-sc-print-btn" target="_blank" title="<?php esc_attr_e( 'Print', 'kdna-ecommerce' ); ?>">&#x1f5b6;</a>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    // =========================================================================
    // Get Available Coupons
    // =========================================================================

    public function get_available_coupons() {
        $s          = self::get_settings();
        $max        = (int) $s['max_coupons_shown'];
        if ( $max <= 0 ) {
            return [];
        }
        $user_email = '';
        $user_id    = get_current_user_id();
        if ( $user_id ) {
            $user       = get_userdata( $user_id );
            $user_email = $user ? $user->user_email : '';
        }

        // Get storewide-visible coupons + user-specific coupons.
        $args = [
            'post_type'      => 'shop_coupon',
            'post_status'    => 'publish',
            'posts_per_page' => $max * 2,
            'meta_query'     => [
                'relation' => 'OR',
                [ 'key' => self::META_IS_VISIBLE_STOREWIDE, 'value' => 'yes' ],
                [ 'key' => 'customer_email', 'compare' => 'NOT EXISTS' ],
                [ 'key' => 'customer_email', 'value' => '', 'compare' => '=' ],
            ],
        ];

        $posts   = get_posts( $args );
        $coupons = [];

        foreach ( $posts as $post ) {
            $coupon = new WC_Coupon( $post->ID );

            // Email restrictions.
            $restrictions = $coupon->get_email_restrictions();
            if ( ! empty( $restrictions ) ) {
                if ( ! $user_email || ! in_array( strtolower( $user_email ), array_map( 'strtolower', $restrictions ), true ) ) {
                    continue;
                }
            }

            // New user restriction.
            if ( get_post_meta( $coupon->get_id(), self::META_RESTRICT_NEW_USER, true ) === 'yes' ) {
                if ( $user_id && wc_get_customer_order_count( $user_id ) > 0 ) {
                    continue;
                }
            }

            // Usage limits.
            if ( $coupon->get_usage_limit() > 0 && $coupon->get_usage_count() >= $coupon->get_usage_limit() ) {
                continue;
            }
            if ( $user_id && $coupon->get_usage_limit_per_user() > 0 ) {
                $data_store = WC_Data_Store::load( 'coupon' );
                if ( $data_store->get_usage_by_user_id( $coupon, $user_id ) >= $coupon->get_usage_limit_per_user() ) {
                    continue;
                }
            }

            // Expiry.
            $expiry = $coupon->get_date_expires();
            if ( $expiry && $expiry->getTimestamp() < time() ) {
                continue;
            }

            $coupons[] = $coupon;
            if ( count( $coupons ) >= $max ) {
                break;
            }
        }

        return $coupons;
    }

    // =========================================================================
    // AJAX Apply Coupon
    // =========================================================================

    public function ajax_apply_coupon() {
        $code = isset( $_POST['coupon_code'] ) ? sanitize_text_field( wp_unslash( $_POST['coupon_code'] ) ) : '';
        if ( empty( $code ) || ! wp_verify_nonce( $_POST['nonce'] ?? '', 'kdna_sc_apply_' . $code ) ) {
            wp_send_json_error( [ 'message' => __( 'Invalid request.', 'kdna-ecommerce' ) ] );
        }
        if ( WC()->cart->has_discount( $code ) ) {
            wp_send_json_error( [ 'message' => __( 'Coupon already applied.', 'kdna-ecommerce' ) ] );
        }
        $result = WC()->cart->apply_coupon( $code );
        if ( $result ) {
            wp_send_json_success( [ 'message' => __( 'Coupon applied successfully!', 'kdna-ecommerce' ) ] );
        } else {
            wp_send_json_error( [ 'message' => __( 'Coupon could not be applied.', 'kdna-ecommerce' ) ] );
        }
    }

    // =========================================================================
    // Shortcode
    // =========================================================================

    public function shortcode_available_coupons( $atts ) {
        $atts = shortcode_atts( [
            'design'  => '',
            'color'   => '',
            'text'    => '',
            'heading' => __( 'Available Coupons', 'kdna-ecommerce' ),
        ], $atts );

        $coupons = $this->get_available_coupons();
        if ( empty( $coupons ) ) {
            return '';
        }

        $s       = self::get_settings();
        $design  = $atts['design'] ?: $s['coupon_design'];
        $bg      = $atts['color'] ?: $s['custom_bg_color'];
        $fg      = $atts['text'] ?: $s['custom_fg_color'];

        ob_start();
        echo '<div class="kdna-sc-available-coupons">';
        if ( $atts['heading'] ) {
            echo '<h3 class="kdna-sc-heading">' . esc_html( $atts['heading'] ) . '</h3>';
        }
        echo '<div class="kdna-sc-coupon-grid kdna-sc-design-' . esc_attr( $design ) . '">';
        foreach ( $coupons as $coupon ) {
            $this->render_coupon_card( $coupon, $design, $bg, $fg );
        }
        echo '</div></div>';
        return ob_get_clean();
    }

    // =========================================================================
    // Frontend Assets
    // =========================================================================

    public function enqueue_styles() {
        if ( ! is_cart() && ! is_checkout() && ! is_account_page() && ! is_product() ) {
            return;
        }

        wp_enqueue_style(
            'kdna-smart-coupons',
            KDNA_ECOMMERCE_URL . 'modules/smart-coupons/assets/smart-coupons.css',
            [],
            KDNA_ECOMMERCE_VERSION
        );

        wp_enqueue_script(
            'kdna-smart-coupons',
            KDNA_ECOMMERCE_URL . 'modules/smart-coupons/assets/smart-coupons.js',
            [ 'jquery' ],
            KDNA_ECOMMERCE_VERSION,
            true
        );

        wp_localize_script( 'kdna-smart-coupons', 'kdna_sc', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'applying' => __( 'Applying...', 'kdna-ecommerce' ),
            'applied'  => __( 'Applied', 'kdna-ecommerce' ),
            'error'    => __( 'Error', 'kdna-ecommerce' ),
        ] );
    }
}
